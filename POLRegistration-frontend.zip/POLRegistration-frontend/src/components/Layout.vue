<template>
  <v-app id="inspire">
    <v-toolbar dark dense fixed app clipped-right class="nav-header">
      <header>
        <a
          @click="backButton"
          v-if="title !== 'Registration'"
          class="back-btn"
        >
          <v-icon size="24" color="white" right>arrow_back</v-icon>
        </a>
        <div class="page-title">{{ title }}</div>
      </header>
    </v-toolbar>
    <v-container fluid style="z-index:1;">
      <BannerComponent />
    </v-container>

    <v-content>
      <v-container
        fluid
        fill-height
        :class="bannerShow ? 'pt-4' : 'padding-banner'"
      >
        <v-layout>
          <section class="wrapper">
            <ErrorComponent
              :modelError="sessionDialog"
              :onCloseDialog="redirectToStart"
              :onClose="redirectToStart"
              header-info="We're sorry"
              body-info="Session has expired. Please try again."
              body-description=""
              actionTitle="OK"
            />
            <router-view></router-view>
          </section>
        </v-layout>
      </v-container>
    </v-content>
  </v-app>
</template>

<script>
import { mapGetters, mapActions } from "vuex";
import ErrorComponent from "@/components/error-component";
import BannerComponent from "@/components/banner-component";
import Api from '@/shared/api'
export default {
  data() {
    return {
      drawer: true,
      items: [],
      left: false,
      navigate: false,
    };
  },
  components: {
    ErrorComponent,
    BannerComponent,
  },
  computed: {
    ...mapGetters([
      "sessionBanner",
      "sessionDialog",
      "viewRegistration",
      "auth_params",
      "bannerShow",
      "getApplicationSource"
    ]),
  },
  props: {
    title: String,
  },
  created() {},
  methods: {
    ...mapActions(["changeSessionDialog"]),
    redirectToStart() {
      this.changeSessionDialog(false);
      Api.redirectToLogin(this.getApplicationSource)
      // let path = "/registration";
      // if (this.viewRegistration) {
      //   path = `/registration/?${this.auth_params.session}`;
      // }
      // this.$router.replace({ path });
    },
    view(routeName) {
      this.setPageDestination(routeName);
      this.$router.push({ name: routeName, params: { navigate: true } });
    },
    backButton() {
      this.setPageDestination(this.$route.meta.prev);
      this.$router.go(-1);
    }
  },
};
</script>

<style scoped>
.v-content {
  padding: 0px 0px 0px !important ;
}
.padding-banner {
  padding: 64px 0px 0px !important;
}
p {
  font-size: 30px;
}
</style>
