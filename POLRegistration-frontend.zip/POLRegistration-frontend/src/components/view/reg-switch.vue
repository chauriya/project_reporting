<template>
    <div>
        <!-- <registration  v-if="viewRegistration"/>
        <registrationFull v-else/> -->
        <verify-info />
    </div>
</template>

<script>
import { mapGetters, mapActions } from "vuex";
// import registration from './registration.vue';
// import registrationFull from './registration-full.vue';
import verifyInfo from './verify-info.vue';
export default {
    computed: {
    ...mapGetters(["viewRegistration"]),
  },
    components: {
        // registration,
        // registrationFull,
        verifyInfo
    },
    methods: {
        ...mapActions(["resetBannerTimer", "setViewRegistration", "setApplicationSource"]),
    },
    created() {
        // var hostName = window.location.hostname;
        // var hostEnv = hostName.split(".")[0];
        this.$store.dispatch("resetState");
        this.resetBannerTimer();
        // if (hostEnv == "localhost" || hostEnv == "dev" || hostEnv == "test") {
            this.setViewRegistration(Object.keys(this.$route.query)[0]);
        // }
        this.setApplicationSource(this.$route.query.applicationSource);
    }
}
</script>