

function alphaNumNoSpace(value){
    var re = /^(?=.*[0-9])(?=.*[a-zA-Z])([a-zA-Z0-9]+)$/; // checks alpha numberic without space
    if(value != "") {
        this.alphaNum = re.test(value);
    }else{
        this.alphaNum = false;
    }
    return re.test(value);
}

function no2SameChar(value){
    var re = /([a-z0-9!@#$%^&*(),.?":{}|<>])\1/; // checks no consecutive 2 same characters
    if(value != "") {
        this.noSameChar = !re.test(value);
    }else{
        this.noSameChar = false;
    }
    // console.log(this.noSameChar);
    return !re.test(value);
}

function checkLowerUpperCase(value){
    var re = /(?=.*[a-z])(?=.*[A-Z]).*/; // checks lower and uppercase
    if(value != "") {
        this.lowerUpperChar = re.test(value);
    }else{
        this.lowerUpperChar = false;
    }
    // console.log(this.lowerUpperChar);
    return re.test(value);
}

function charNotAllowed(value) {
    var re = /([''<>])/; // checks ' ' < > chars allowed
    if(value != "") {
        this.restrictChar = !re.test(value);
    }else{
        this.restrictChar = false;
    }
    console.log(this.$v.form);
    return !re.test(value);
}