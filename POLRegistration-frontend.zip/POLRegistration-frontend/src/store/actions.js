import Dna from "@/shared/deviceDna";
import Api from "@/shared/api";

export const resetState = ({ commit }) => {
  commit("resetState");
};

export const setAuthParams = async ({ commit }, auth_params) => {
  commit("setAuthParams", auth_params);
};

export const setViewRegistration = async ({ commit, dispatch }, value) => {
  commit("setViewRegistration", true); // Forcefully making beta registration available
  dispatch("setAuthParams", { session: value });
};

export const changeSessionDialog = ({ commit }, value) => {
  commit("changeSessionDialog", value);
};

export const startBannerTimer = ({ commit, dispatch }) => {
  let bannerTimer = setTimeout(() => {
    dispatch("showBanner", {
      type: "warning",
      message: "You're session is going to expire in 5 minutes.",
    });
    dispatch("startDialogTimer");
  }, 55 * 60 * 1000);
  commit("setBannerTimer", bannerTimer);
};

export const startDialogTimer = ({ commit, dispatch }) => {
  let dialogTimer = setTimeout(() => {
    dispatch("changeSessionDialog", true);
  }, 5 * 60 * 1000);
  commit("setDialogTimer", dialogTimer);
};

export const resetBannerTimer = ({ getters }) => {
  clearTimeout(getters.sessionTimer.banner);
  clearTimeout(getters.sessionTimer.dialog);
};
export const setApplicationSource = ({ commit }, value) => {
  commit("setApplicationSource", value);
};

export const showBanner = async (
  { commit, dispatch },
  { type = "", message = "", onClose = () => 1 }
) => {
  dispatch("hideBanner");
  commit("showBanner", { type, message, onClose });
  window.scrollTo(0, 0);
  let bannerTimer = setTimeout(() => {
    dispatch("hideBanner");
  }, 10000);
  commit("setBannerTimer", bannerTimer);
};

export const hideBanner = async ({ commit, getters }) => {
  clearTimeout(getters.bannerTimer);
  commit("hideBanner");
};
export const verificationUser = async ({ state, commit }) => {
  try {
    const { auth_params, reg_form, ui } = state;
    const verificationUserHead = {
      deviceid: localStorage.getItem("deviceid"),
      deviceDna: await Dna.getDevice(),
      session: auth_params.session,
      sourceKey: reg_form.userId,
      applicationSource: ui.applicationSource,
      userId: reg_form.userId,
      "Content-Type": "application/json",
    };

    const { data, status } = await Api.getRequest(
      `pol/registration/api/verification/user/${reg_form.regType}/${
        reg_form.userId
      }`,
      verificationUserHead
    );

    if (status == "204") {
      // @TODO this.showBanner(this.genericError);
      return false;
    }
    commit("setInfoForm", data.agentData[0]);
    return true;
  } catch {
    // return false;
    this.showBanner({
      type: "warning",
      message:
        "Unable to register you online. Please call (888) 737-2255 US or (905) 812-3520 Canada for assistance with your account.",
    });
  }
};

export const setPageDestination = async ({ commit }, value) => {
  commit('setPageDestination', value);
}
export const setHostName = async ({ commit }, hostName) => {
  commit("setHostName", hostName);
};
