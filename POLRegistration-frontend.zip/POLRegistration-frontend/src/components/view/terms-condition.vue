<template>
  <section class="page-wrap condition-page" id="editor" ref="editor">
    <BannerComponent
      :value.sync="genericError"
      type="warning"
      message="Unable to register you online. Please call (888) 737-2255 US or (905) 812-3520 Canada for assistance with your account."
    />
    <v-content class="condition-wrap" id="content-wrapper">
      <div v-html="htmlRetrived"></div>
      <div id="scroll-continue" style="height:3px;"></div>
    </v-content>
    <div app class="term-footer mt-4" v-if="buttonLoaded">
      <div v-if="mobileView">
        <div class="scroll-section-removed">
          <div v-if="disableButton" class="scroll-tab-wrap">
            <div class="scroll-tab">
              <h4>Scroll to Continue</h4>
            </div>
          </div>
        </div>
        <v-flex class="fixed-footer">
          <div class="btn-wrap">
            <v-btn
              v-if="!disableButton"
              class="btn btn-primary primary-color"
              v-on:click="acceptTerm()"
              >I Accept</v-btn
            >
            <CancelButtonComponent
              :btnName="`Decline`"
              :cancelCategory="`2FAreg.terms`"
            />
          </div>
        </v-flex>
      </div>
      <div v-else>
        <div class="scroll-section">
          <div v-if="disableButton" class="scroll-tab-wrap">
            <div class="scroll-tab">
              <h4>Scroll to Continue</h4>
            </div>
          </div>
        </div>
        <v-flex class="fixed-footer">
          <div class="btn-wrap">
            <v-btn
              v-if="showAccept"
              :disabled="disableButton"
              class="btn btn-primary primary-color"
              v-on:click="acceptTerm()"
              >I Accept</v-btn
            >
            <CancelButtonComponent
              :btnName="`Decline`"
              :cancelCategory="`2FAreg.terms`"
            />
          </div>
        </v-flex>
      </div>
    </div>
    <LoaderComponent v-if="dataload" />
  </section>
</template>

<script>
/* eslint-disable */
import { mapState, mapMutations, mapActions, mapGetters } from "vuex";
import LoaderComponent from "@/components/loader-component";
import CancelButtonComponent from "@/components/cancel-component";
import Api from "../../shared/api";
import Logger from "../../shared/logger.js";
import Gtm from "../../shared/gtm.js";
import Dna from "../../shared/deviceDna.js";
import axios from "axios";
import BannerComponent from "@/components/banner-component";
import { getPlatform } from "../../shared/deviceDetect";
export default {
  components: {
    LoaderComponent,
    CancelButtonComponent,
    BannerComponent,
  },
  data: () => ({
    showAccept: true,
    mobileView: false,
    scrollTo: true,
    startScroll: "",
    loaded: false,
    termConditions: "",
    genericError: false,
    dataload: false,
    staticHtmlUrl: "",
    htmlRetrived: "",
    scrolledToBottom: false,
    disableButton: true,
    buttonLoaded: false,
  }),
  computed: {
    ...mapState(["reg_form", "auth_params", "auth_otp"]),
    ...mapGetters(["getApplicationSource"]),
  },
  async created() {
    if (this.$vuetify.breakpoint.xs) {
      this.showAccept = false;
      this.mobileView = true;
    }
    this.dataload = true;
    // axios.get("https://dev.primericaonline.com/NAPOLWelcome/public/useragreement/08-25-2016_Subscription_and_Use_Agreement.html").then(response => {
    //     this.htmlRetrived = response.data
    //     this.buttonLoaded = true;
    // if (getPlatform() === 'BIPOL') {
    //    document.getElementById("editor").style.position = 'absolute';
    // }
    // })
    Gtm.gtmPageView("2FAreg.terms");
    var termsUserHead = {
      regType: this.reg_form.regType,
      session: this.auth_params.session,
      deviceid: localStorage.getItem("deviceid"),
      deviceDna: await Dna.getDevice(),
      docType: "HTML",
      sourceKey: this.reg_form.userId,
      userId: this.reg_form.userId,
      applicationSource: this.getApplicationSource,
    };
    Api.getRequest("pol/registration/api/serviceagreementpath", termsUserHead)
      .then((response) => {
        let data = response.data;
        var hostName = window.location.hostname;
        var hostEnv = hostName.split(".")[0];
        if (hostEnv == "localhost") {
          hostEnv = "dev";
        }
        // this.staticHtmlUrl = "https://dev.primericaonline.com/NAPOLWelcome/public/useragreement/08-25-2016_Subscription_and_Use_Agreement.html"
        this.staticHtmlUrl =
          "https://" +
          hostEnv +
          ".primericaonline.com" +
          data.ServiceAgreementPath;
        axios.get(this.staticHtmlUrl).then((response) => {
          this.htmlRetrived = response.data;
          this.buttonLoaded = true;
          this.dataload = false;
        });
      })
      .catch((error) => {
        this.dataload = false;
        this.genericError = true;
      });
  },
  mounted() {
    if (
      this.getApplicationSource === "PriApp" &&
      getPlatform() === "BIPOL" &&
      this.$vuetify.breakpoint.xs
    ) {
      document.getElementById("content-wrapper").style.maxWidth =
        document.body.clientWidth - 15 + "px";
    }
    const deviceViewPortHeight = Math.max(
      document.documentElement.clientHeight || 0,
      window.innerHeight || 0
    );
    ["content-wrapper", "editor"].forEach(function(id) {
      document.getElementById(id).style.maxHeight =
        deviceViewPortHeight - 150 - 64 + "px";
    });
    this.scroll();
  },
  beforeDestroy() {
    clearInterval(this.startScroll);
  },
  methods: {
    acceptTerm() {
      Gtm.gtmClickEvent("event", "2FAreg.terms", "accept", "terms");
      this.setPageDestination('password-setup');
      this.$router.push({ name: "password-setup" });
    },

    scroll() {
      const vm = this;
      this.startScroll = setInterval(function() {
        var myElement = document.getElementById("scroll-continue");
        if (myElement) {
          var bounding = myElement.getBoundingClientRect();
        }
        if (
          bounding.top >= 0 &&
          bounding.left >= 0 &&
          parseInt(bounding.right) <= window.innerWidth &&
          bounding.bottom <= window.innerHeight
        ) {
          vm.disableButton = false;
          if (vm.mobileView) {
            vm.showAccept = true;
          }
        } else {
          vm.disableButton = true;
          if (vm.mobileView) vm.showAccept = false;
        }
      }, 500);
    },
  },
};
</script>
<style scoped>
#content-wrapper {
  overflow-y: scroll;
  scrollbar-width: none; /* Firefox */
  -ms-overflow-style: none; /* Internet Explorer 10+ */
}
#content-wrapper::-webkit-scrollbar {
  /* WebKit */
  width: 0;
  height: 0;
}
.scroll-section {
  height: 50px;
}
</style>
