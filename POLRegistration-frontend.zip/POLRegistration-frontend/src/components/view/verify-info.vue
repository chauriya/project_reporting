<template>
  <section class="page-wrap authentication-page" padding>
    <v-form @submit.prevent="submitForm" v-if="stateClear">
      <section class="form-wrap">
        <div class="account-block">
          <div class="sub-title p-b-15">
            <p class="bol">Is this you?</p>
            <p>
              If not, go back to re-enter your information.You will be able to
              update your information after registration.
            </p>
          </div>

          <div class="user-info">
            <h4>Rep ID</h4>
            <h5>{{ reg_form.userId }}</h5>
          </div>
          <div class="user-info">
            <h4>Name</h4>
            <h5>{{ info_form.firstName }} {{ info_form.lastName }}</h5>
          </div>
          <div class="user-info">
            <h4>Title</h4>
            <h5>{{ info_form.displayTitle }}</h5>
          </div>
          <div class="user-info">
            <h4>RVP</h4>
            <h5>{{ info_form.rvpFirstName }} {{ info_form.rvpLastName }}</h5>
          </div>
          <div
            class="user-info"
            v-if="info_form.doNotDisplayAddress == '1' ? false : true"
          >
            <h4>Address</h4>
            <h5>{{ info_form.addr1 }}</h5>
            <h5>
              {{ info_form.city }}, {{ info_form.state }} {{ info_form.zip }}
            </h5>
          </div>
          <br />
        </div>
        <div class="form-row">
          <div class="btn-wrap">
            <v-btn
              class="btn btn-primary primary-color"
              v-on:click="communication()"
              >Next</v-btn
            >
            <CancelButtonComponent
              :btnName="`Cancel`"
              :cancelCategory="`2FAreg.ver`"
            />
          </div>
        </div>
      </section>
    </v-form>
    <FooterComponent v-if="stateClear" />
    <LoaderComponent v-if="dataload" />
  </section>
</template>

<script>
import FooterComponent from "@/components/footer-component";
import CancelButtonComponent from "@/components/cancel-component";
import { mapState, mapGetters, mapActions } from "vuex";
import axios from "axios";
import Api from "../../shared/api";
import Gtm from "../../shared/gtm.js";
import LoaderComponent from "@/components/loader-component";

export default {
  components: {
    FooterComponent,
    CancelButtonComponent,
    LoaderComponent
  },
  data: () => ({
    stateClear: true,
    dataload: false,
    genericError: {
      type: "warning",
      message:
        "Unable to register you online. Please call (888) 737-2255 US or (905) 812-3520 Canada for assistance with your account.",
    }
  }),
  computed: {
    ...mapState(["info_form", "reg_form", "auth_params"]),
    ...mapGetters(["getApplicationSource"]),
  },
  async created() {
    Gtm.gtmPageView("2FAreg.verify");
    await this.getSessionInfo();
    await this.userVerification();
  },
  mounted() {},
  methods: {
    ...mapActions(["startBannerTimer", "verificationUser"]),
    async getSessionInfo() {
      try {
      this.dataload = true;
      const response = await Api.getRequest("pol/session/info", { session: this.auth_params.session })
          this.reg_form.userId = response.data.userId;
          this.reg_form.regType = response.data.regType;
          this.dataload = false;
        } catch {
          this.dataload = false;
          Api.redirectToLogin(this.getApplicationSource)
        }
    },
    async userVerification() {
      try {
      this.dataload = true;
      await this.verificationUser();
          this.dataload = false;
        this.info_form.mobNumber = this.info_form.mobilePhoneNumber;
      } catch {
        this.dataload = false;
        this.showBanner(this.genericError);
      }
    },
    communication() {
      Gtm.gtmClickEvent("event", "2FAreg.ver", "click", "next");
      var hostName = window.location.hostname;
      var hostEnv = hostName.split(".")[0];
      var baseUrl = "https://" + hostEnv + ".primericaonline.com/";
      axios.get(baseUrl + "registration/logout");
      this.startBannerTimer();
      this.setPageDestination('communication');
      this.$router.push({ name: "communication" });
    },
  },
};
</script>
