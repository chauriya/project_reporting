<template>
  <v-layout row justify-center>
    <v-dialog v-model="modelError" persistent max-width="470">
      <div class="dialog error-dialog">
        <v-card>
          <div class="top-bar"></div>
          <v-card-title class="headline">
            <div><v-icon size="28" color="#f39c12">warning</v-icon></div>
            <span :class="{ 'title-width': $vuetify.breakpoint.xs }">{{
              headerInfo
            }}</span>
            <v-spacer></v-spacer>
            <div class="dialog-close">
              <span v-on:click="closeDialog"
                ><v-icon size="28" right>close</v-icon></span
              >
            </div>
          </v-card-title>
          <v-card-text class="dialog-text">
            <p class="d-info">{{ bodyInfo }}</p>
            <p class="d-desc" v-html="bodyDescription" />
          </v-card-text>
          <v-divider v-if="actionTitle"></v-divider>
          <v-card-actions v-if="actionTitle">
            <v-spacer></v-spacer>
            <v-btn
              class="text-capitalize action-btn"
              text
              small
              @click.native="close"
              flat
              >{{ actionTitle }}</v-btn
            >
          </v-card-actions>
        </v-card>
      </div>
    </v-dialog>
  </v-layout>
</template>
<script>
export default {
  props: {
    modelError: {
      default: false,
    },
    headerInfo: "",
    bodyInfo: "",
    bodyDescription: "",
    actionTitle: "",
    onClose: {
      type: Function,
      default: () => 1,
    },
    onCloseDialog: {
      type: Function,
      default: () => 1,
    },
  },
  mounted() {},
  created() {},
  methods: {
    close() {
      this.onClose();
      this.$emit("update:modelError", false);
    },
    closeDialog() {
      this.onCloseDialog();
      this.$emit("update:modelError", false);
    },
  },
};
</script>
<style scoped>
.top-bar {
  padding: 4px;
  background: #f39c12;
  margin-bottom: 5px;
}
.title-width {
  max-width: 150px;
  line-height: 1.5;
}
.dialog-close {
  /* margin: 0px 0 26px 0; */
  padding: 0px !important;
}
.action-btn {
  color: #02579e !important;
  font-size: 14px;
  font-weight: 600;
}
@media screen and (max-width: 767px) {
  .v-card__title {
    align-items: unset;
  }
}
</style>
