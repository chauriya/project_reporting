<template>
  <v-btn class="btn btn-outline primary-color" v-on:click="cancelBtnClick">{{
    btnName
  }}</v-btn>
</template>

<script>
import { mapGetters } from "vuex";
import Gtm from "../shared/gtm.js";
export default {
  props: {
    btnName: "",
    cancelCategory: "",
  },
  created() {},
  computed: {
    ...mapGetters(["viewRegistration", "auth_params", "getApplicationSource"]),
  },
  methods: {
    cancelBtnClick: function() {
      if (
        this.cancelCategory == "2FAreg.terms" ||
        this.cancelCategory == "2FAreg.setPw"
      ) {
        Gtm.gtmClickEvent("event", this.cancelCategory, "decline", "terms");
      } else {
        Gtm.gtmClickEvent("event", this.cancelCategory, "click", "cancel");
      }
      let params = "";
      if (this.viewRegistration) {
        params = `/?${this.auth_params.session}`;
      }
      var hostName = window.location.hostname;
      var hostEnv = hostName.split(".")[0];
      if (hostEnv == "localhost") {
        window.open(`/registration${params}`, "_self");
        return;
      }
      if (this.getApplicationSource === "PriApp") {
        window.parent.postMessage("PRIAPPLOGIN", "*");
      } else {
        window.open(`https://${hostEnv}.primericaonline.com`, "_self");
      }
    },
  },
};
</script>
