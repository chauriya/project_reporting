<template>
  <section class="page-wrap authentication-page" padding>
    <div class="title">
      <h2>Welcome to Primerica Online Registration</h2>
    </div>
    <v-form @submit.prevent="submitForm">
      <section class="form-wrap">
        <div class="form-row">
          <div class="sub-title">
            <p>
              Please enter the following personal information so that we can
              identify you.
            </p>
          </div>
        </div>
        <div class="form-row form-height">
          <v-text-field
            label="Rep ID / User ID"
            v-model="$v.form.repId.$model"
            maxlength="7"
            @blur="$v.form.repId.$touch()"
            :success="$v.form.repId.LengthFiveOrSeven && $v.form.repId.required"
            :error="
              $v.form.repId.$dirty &&
                (!$v.form.repId.required || !$v.form.repId.LengthFiveOrSeven)
            "
            :append-icon="setIconRepId()"
          ></v-text-field>
          <div class="error-grp">
            <div
              class="error"
              v-if="!$v.form.repId.required && $v.form.repId.$dirty"
            >
              RepId is required
            </div>
            <div
              class="error"
              v-if="
                !$v.form.repId.LengthFiveOrSeven &&
                  $v.form.repId.required &&
                  $v.form.repId.$dirty
              "
            >
              Invalid Rep ID
            </div>
          </div>
        </div>
        <div class="form-row form-height">
          <v-text-field
            label="SSN / SIN"
            id="ssn-sin"
            class="form-hint"
            v-model="$v.form.ssnSin.$model"
            v-numericOnly
            @blur="
              $v.form.ssnSin.$touch();
              inputBlur();
            "
            @focus="inputFocus"
            :class="fMask ? 'f-mask' : ''"
            inputmode="numeric"
            maxlength="9"
            hint="This helps us connect you to the correct information and helps protect your information from unauthorized access."
            type="tel"
            :success="
              $v.form.ssnSin.only9Digit &&
                $v.form.ssnSin.required &&
                $v.form.ssnSin.$dirty
            "
            :error="
              $v.form.ssnSin.$dirty &&
                (!$v.form.ssnSin.required || !$v.form.ssnSin.only9Digit)
            "
          >
            <span slot="append">
              <v-icon
                class="toggle-masking primary-color"
                @click="toggleMasked"
                :class="iconAppend ? 'active' : ''"
              >
                {{ masked ? "visibility" : "visibility_off" }}
              </v-icon>
              <v-icon
                class="toggle-masking"
                :class="iconAppend ? 'active' : ''"
                v-if="$v.form.ssnSin.only9Digit"
                >{{ "check_circle" }}
              </v-icon>
              <v-icon
                class="toggle-masking"
                :class="iconAppend ? 'active' : ''"
                v-if="
                  $v.form.ssnSin.$dirty &&
                    (!$v.form.ssnSin.required || !$v.form.ssnSin.only9Digit)
                "
                >{{ "error" }}
              </v-icon>
            </span>
          </v-text-field>
          <div class="error-grp">
            <div
              class="error"
              v-if="!$v.form.ssnSin.required && $v.form.ssnSin.$dirty"
            >
              SSN/SIN is required
            </div>
            <div
              class="error"
              v-if="
                !$v.form.ssnSin.only9Digit &&
                  $v.form.ssnSin.required &&
                  $v.form.ssnSin.$dirty
              "
            >
              SSN/SIN must be exactly 9 digits
            </div>
          </div>
        </div>
        <div class="form-row form-height">
          <v-text-field
            :label="$t('registration.DOB.label')"
            id="date"
            :appendIcon="setIconDate()"
            @input="dateInput"
            @blur="$v.form.datestring.$touch()"
            v-numericOnly
            mask="##/##/####"
            maxlength="8"
            v-model="$v.form.datestring.$model"
            :success="$v.form.datestring.checkDateInput"
            :error="
              (!$v.form.datestring.required ||
                !$v.form.datestring.checkDateInput) &&
                $v.form.datestring.$dirty
            "
            type="tel"
          >
          </v-text-field>
          <div class="error-grp">
            <div
              class="error"
              v-if="!$v.form.datestring.required && $v.form.datestring.$dirty"
            >
              {{ $t("registration.DOB.error1") }}
            </div>
            <div
              class="error"
              v-if="
                !$v.form.datestring.checkDateInput &&
                  $v.form.datestring.required &&
                  $v.form.datestring.$dirty
              "
            >
              {{ $t("registration.DOB.error2") }}
            </div>
          </div>
        </div>
        <div class="form-row form-height">
          <!-- <label for="email" class="form-label">Non-Primerica Email Address</label> -->
          <v-text-field
            label="Non-Primerica Email Address"
            id="email"
            maxlength="100"
            oncopy="return false"
            onpaste="return false"
            :appendIcon="setIconEmail()"
            @input="setEmail()"
            v-model="$v.form.emailId.$model"
            @blur="$v.form.emailId.$touch()"
            :success="
              $v.form.emailId.email &&
                $v.form.emailId.required &&
                $v.form.emailId.checkPrimerica
            "
            :error="
              (!$v.form.emailId.required ||
                !$v.form.emailId.email ||
                !$v.form.emailId.checkPrimerica) &&
                $v.form.emailId.$dirty
            "
          >
          </v-text-field>
          <div class="error-grp">
            <div
              class="error"
              v-if="!$v.form.emailId.required && $v.form.emailId.$dirty"
            >
              An email address is required
            </div>
            <div
              class="error"
              v-if="!$v.form.emailId.email && $v.form.emailId.$dirty"
            >
              The email address entered is not valid
            </div>
            <div
              class="error"
              v-if="!$v.form.emailId.checkPrimerica && $v.form.emailId.$dirty"
            >
              Cannot enter @primerica.com email address
            </div>
          </div>
        </div>
        <div class="form-row form-height">
          <v-text-field
            label="Confirm Email Address"
            id="confirmemail"
            maxlength="100"
            oncopy="return false"
            onpaste="return false"
            @input="setConfirmEmail()"
            :appendIcon="setConfirmIconEmail()"
            v-model="$v.form.confirmemailId.$model"
            @blur="$v.form.confirmemailId.$touch()"
            :success="
              bothEmailMatch() &&
                $v.form.confirmemailId.email &&
                $v.form.confirmemailId.required &&
                $v.form.confirmemailId.checkPrimerica
            "
            :error="
              (!$v.form.confirmemailId.required ||
                !$v.form.confirmemailId.email ||
                !$v.form.confirmemailId.checkPrimerica ||
                !bothEmailMatch()) &&
                $v.form.confirmemailId.$dirty
            "
          >
          </v-text-field>
          <div class="error-grp">
            <div
              class="error"
              v-if="
                !$v.form.confirmemailId.required &&
                  $v.form.confirmemailId.$dirty
              "
            >
              An email address is required
            </div>
            <div
              class="error"
              v-if="
                !$v.form.confirmemailId.email && $v.form.confirmemailId.$dirty
              "
            >
              Enter a valid Email address
            </div>
            <div
              class="error"
              v-if="
                !$v.form.confirmemailId.checkPrimerica &&
                  $v.form.confirmemailId.$dirty
              "
            >
              Cannot enter @primerica.com email address
            </div>
            <div
              class="error"
              v-else-if="
                !bothEmailMatch() &&
                  $v.form.confirmemailId.required &&
                  $v.form.confirmemailId.email
              "
            >
              Those email addresses didn't match. Try again
            </div>
          </div>
        </div>
        <div class="form-row">
          <div class="btn-wrap">
            <v-btn
              class="btn btn-primary primary-color"
              @click.prevent="submitForm"
              :disabled="$v.form.$invalid || !formValid()"
              >Next</v-btn
            >
            <CancelButtonComponent
              :btnName="`Cancel`"
              :cancelCategory="`2FAreg`"
            />
          </div>
        </div>
      </section>
    </v-form>
    <div class="align-center footer-link">
      <a @click="redirectToApplication">Already have a POL account?</a>
    </div>
    <FooterComponent />
    <LoaderComponent v-if="dataload" />
    <ErrorComponent
      :modelError.sync="regTerminatedError"
      header-info="We're sorry."
      body-info="Your POL Owner subscription is terminated"
      body-description="You cannot register for POL. For questions, contact your Rep/RVP."
    />
    <ErrorComponent
      :modelError.sync="precodedError"
      header-info="We're sorry"
      body-description="You cannot register for POL. For questions, contact your Rep/RVP."
    />
    <ErrorComponent
      :modelError.sync="regOfficeUsersAgentTerminatedErr"
      header-info="We're sorry"
      body-info="Your POL Owner subscription is terminated."
      body-description="You cannot register for POL. For questions, contact your Rep/RVP."
    />
  </section>
</template>

<script>
import {
  required,
  numeric,
  email,
  sameAs,
  minLength,
  maxLength,
} from "vuelidate/lib/validators";
import { numericOnly } from "@/directives/fieldDirectives";
import FooterComponent from "@/components/footer-component";
import LoaderComponent from "@/components/loader-component";
import ErrorComponent from "@/components/error-component";
import CancelButtonComponent from "@/components/cancel-component";
import Dna from "../../shared/deviceDna.js";
import { mapState, mapActions, mapGetters } from "vuex";
import Api from "../../shared/api";
import Gtm from "../../shared/gtm.js";

export default {
  components: {
    FooterComponent,
    LoaderComponent,
    CancelButtonComponent,
    ErrorComponent,
  },
  data: (vm) => ({
    ssnSinval: "",
    masked: true,
    fMask: true,
    date: null,
    menu: false,
    datePicker: false,
    modal: false,
    only9Digit: false,
    checkDateInput: false,
    emailId: "",
    confirmemailId: "",
    form: {
      repId: "",
      ssnSin: "",
      emailId: "",
      datestring: "",
      confirmemailId: "",
    },
    genericError: {
      type: "warning",
      message:
        "Unable to register you online. Please call (888) 737-2255 US or (905) 812-3520 Canada for assistance with your account.",
    },
    wrongInfoError: {
      type: "warning",
      message:
        "The information entered was incorrect. Please try again or verify with your RVP that you have access.",
    },
    alreadyRegistered: {
      type: "warning",
      message:
        "Registration Complete. Click <a href='/'>Primerica Online</a> to login.",
    },
    emailTaken: {
      type: "warning",
      message: "The information entered doesn't match our records.",
    },
    regTerminatedError: false,
    precodedError: false,
    regOfficeUsersAgentTerminatedErr: false,
    dataload: false,
    iconAppend: false,

    items: [
      { lang: "English", langcode: "en" },
      { lang: "French", langcode: "fr" },
    ],
    select: { lang: "English", langcode: "en" },
  }),
  validations: {
    form: {
      repId: {
        required,
        LengthFiveOrSeven(val) {
          if (val.length === 5 || val.length === 7) return true;
          return false;
        },
        minLength: minLength(5),
      },
      ssnSin: {
        required,
        only9Digit,
      },
      emailId: {
        required,
        email,
        checkPrimerica,
      },
      datestring: {
        required,
        checkDateInput,
      },
      confirmemailId: {
        required,
        email,
        checkPrimerica,
      },
    },
  },
  created() {
    Gtm.gtmPageView("2FAreg");
    // this.showBanner({ type: "error", message: "some warning msg test" });
  },
  computed: {
    ...mapState(["reg_form", "info_form", "select_user_form", "auth_params"]),
    ...mapGetters(["getApplicationSource"]),
    computedDateFormatted() {
      return this.formatDate(this.date);
    },
  },
  watch: {
    date(val) {
      this.$v.form.datestring.$model = this.formatDate(this.date);
    },
    datePicker: function(val) {
      val && setTimeout(() => (this.$refs.datePicker.activePicker = "YEAR"));
    },
  },
  methods: {
    ...mapActions(["startBannerTimer", "setAuthParams", "verificationUser"]),
    redirectToApplication() {
      var hostName = window.location.hostname;
      var hostEnv = hostName.split(".")[0];
      if (this.getApplicationSource === "PriApp") {
        window.parent.postMessage("PRIAPPLOGIN", "*");
      } else {
        window.open("https://" + hostEnv + ".primericaonline.com", "_self");
      }
    },
    bothEmailMatch() {
      return this.emailId === this.confirmemailId;
    },
    setEmail() {
      this.emailId = this.$v.form.emailId.$model.toLowerCase();
    },
    setConfirmEmail() {
      this.confirmemailId = this.$v.form.confirmemailId.$model.toLowerCase();
    },
    dateInput() {
      var dateInput = "";
      if (
        this.$v.form.datestring.$model &&
        this.$v.form.datestring.$model.length < 9
      ) {
        dateInput =
          this.$v.form.datestring.$model.substring(0, 2) +
          "/" +
          this.$v.form.datestring.$model.substring(2, 4) +
          "/" +
          this.$v.form.datestring.$model.substring(4, 8);
        this.form.datestring = dateInput;
      }
    },
    toggleMasked() {
      this.masked = !this.masked;
      this.fMask = !this.fMask;
    },
    inputFocus() {
      this.iconAppend = true;
    },
    inputBlur() {
      this.iconAppend = false;
    },
    formValid() {
      return (
        this.$v.form.ssnSin.only9Digit &&
        this.$v.form.emailId.checkPrimerica &&
        this.$v.form.datestring.checkDateInput &&
        this.$v.form.repId.LengthFiveOrSeven &&
        this.bothEmailMatch()
      );
    },
    async submitForm() {
      Gtm.gtmClickEvent("event", "2FAreg", "click", "next");
      this.dataload = true;
      var registrationeligibilityHead = {
        userId: this.form.repId,
        ssn: this.form.ssnSin,
        dob: this.form.datestring,
        email: this.form.emailId,
        confirmemail: this.form.confirmemailId,
        deviceDna: await Dna.getDevice(),
        sourceKey: this.form.repId,
        applicationSource: this.getApplicationSource,
        "Content-Type": "application/json",
      };
      Api.getRequest(
        "pol/registration/api/eligibility",
        registrationeligibilityHead
      )
        .then(async (response) => {
          this.reg_form.userId = this.form.repId;
          this.reg_form.ssnSin = this.form.sinSsn;
          this.reg_form.emailId = this.form.emailId;
          this.reg_form.datestring = this.form.datestring;
          if (response.data.message == "regEmailAlreadyTaken") {
            Gtm.gtmClickEvent("event", "2FAreg", "error", "emailTaken");
            this.showBanner(this.emailTaken);
            this.dataload = false;
            return;
          }
          if (
            response.data.regUsers.length == 0 &&
            response.data.message == "regInvalidData"
          ) {
            Gtm.gtmClickEvent("event", "2FAreg", "error", "invalidData");
            this.showBanner(this.wrongInfoError);
            this.dataload = false;
            return;
          }
          if (
            response.data.regUsers.length == 0 &&
            response.data.message == "regPolRegistered"
          ) {
            Gtm.gtmClickEvent("event", "2FAreg", "error", "POLreg");
            this.showBanner(this.alreadyRegistered);
            this.dataload = false;
            return;
          }

          if (
            response.data.regUsers.length == 0 &&
            response.data.message == "regTerminatedAgent"
          ) {
            Gtm.gtmClickEvent("event", "2FAreg", "error", "terminated");
            this.regTerminatedError = true;
            this.dataload = false;
            return;
          }
          if (
            response.data.regUsers.length == 0 &&
            response.data.message == "regVbsRegistered"
          ) {
            Gtm.gtmClickEvent("event", "2FAreg", "error", "VBSreg");
            this.showBanner({
              type: "warning",
              message:
                "You have already registered for Virtual Base Shop. Click cancel to return to the Primerica Online login screen. Then, enter your Rep ID and your password to log in.",
            });
            this.dataload = false;
            return;
          }
          if (
            response.data.regUsers.length == 0 &&
            response.data.message == "regPrecodedCannotRegister"
          ) {
            Gtm.gtmClickEvent("event", "2FAreg", "error", "precoded");
            this.precodedError = true;
            this.dataload = false;
            return;
          }
          if (
            response.data.regUsers.length == 0 &&
            response.data.message == "regOfficeUsersAgentTerminated"
          ) {
            this.regOfficeUsersAgentTerminatedErr = true;
            this.dataload = false;
            return;
          }

          if (response.data.regUsers.length == 0) {
            this.showBanner(this.genericError);
            this.dataload = false;
            return;
          }
          this.auth_params.deviceid = response.headers.deviceid;
          this.setAuthParams({ session: response.headers.session });
          let data = response.data;
          this.reg_form.regType = data.regUsers[0].regType;
          this.reg_form.primaryCo = data.regUsers[0].primaryCo;
          this.reg_form.instantIssueInd = data.instantIssueInd;
          this.reg_form.serviceLevel = data.regUsers[0].serviceLevel;
          this.reg_form.deletePrecoded = data.regUsers[0].deletePrecoded;
          //GTM for regType and serviceLevel
          Gtm.gtmRegType((this.reg_form.regType = data.regUsers[0].regType));
          Gtm.gtmServiceLabel(
            (this.reg_form.serviceLevel = data.regUsers[0].serviceLevel)
          );
          const verificationResponse = await this.verificationUser();
          if (!verificationResponse) {
            this.genericError = true;
            this.dataload = false;
            return;
          }
          this.reg_form.userId = this.info_form.userId;
          this.info_form.mobNumber = this.info_form.mobilePhoneNumber;
          this.startBannerTimer();
          this.setPageDestination('verify-info');
          this.$router.push({ name: "verify-info" });
        })
        .catch((error) => {
          this.dataload = false;
          this.showBanner(this.genericError);
        });
    },
    formatDate(date) {
      if (!date) return null;

      const [year, month, day] = date.split("-");
      return `${month}/${day}/${year}`;
    },
    parseDate(date) {
      if (!date) return null;

      const [month, day, year] = date.split("/");
      return `${year}-${month.padStart(2, "0")}-${day.padStart(2, "0")}`;
    },
    changeLang(lang, langcode) {
      localStorage.setItem("selectedlang", langcode);
      this.$i18n.locale = langcode;
    },
    setIconRepId() {
      if (this.$v.form.repId.required && this.$v.form.repId.LengthFiveOrSeven)
        return "check_circle";
      if (
        (!this.$v.form.repId.required ||
          !this.$v.form.repId.LengthFiveOrSeven) &&
        this.$v.form.repId.$dirty
      )
        return "error";
    },
    setIconDate() {
      if (this.$v.form.datestring.checkDateInput) return "check_circle";
      if (
        (!this.$v.form.datestring.required ||
          !this.$v.form.datestring.checkDateInput) &&
        this.$v.form.datestring.$dirty
      )
        return "error";
    },
    setIconEmail() {
      if (
        this.$v.form.emailId.email &&
        this.$v.form.emailId.required &&
        this.$v.form.emailId.checkPrimerica
      )
        return "check_circle";
      if (
        (!this.$v.form.emailId.required ||
          !this.$v.form.emailId.email ||
          !this.$v.form.emailId.checkPrimerica) &&
        this.$v.form.emailId.$dirty
      )
        return "error";
    },
    setConfirmIconEmail() {
      if (
        this.$v.form.confirmemailId.email &&
        this.$v.form.confirmemailId.required &&
        this.$v.form.confirmemailId.checkPrimerica &&
        this.bothEmailMatch()
      )
        return "check_circle";
      if (
        (!this.$v.form.confirmemailId.required ||
          !this.$v.form.confirmemailId.email ||
          !this.$v.form.confirmemailId.checkPrimerica ||
          !this.bothEmailMatch()) &&
        this.$v.form.confirmemailId.$dirty
      )
        return "error";
    },
    setIconSSN() {
      if (
        this.$v.form.ssnSin.only9Digit &&
        this.$v.form.ssnSin.required &&
        this.$v.form.ssnSin.$dirty
      ) {
        return "check_circle";
      }
      if (
        this.$v.form.ssnSin.$dirty &&
        (!this.$v.form.ssnSin.required || !this.$v.form.ssnSin.only9Digit)
      ) {
        return "error";
      }
    },
  },
};

function checkPrimerica(value) {
  return !value.toLowerCase().includes("@primerica.com");
}
function only9Digit(value) {
  var re = /^(?:\d{9})$/; // Only 9 digit number
  if (value != "") {
    this.only9Digit = re.test(value);
  } else {
    this.only9Digit = false;
  }
  return re.test(value);
}
function checkDateInput(value) {
  var temp = value.split("/");
  var year = value.substring(6, 10).length == 4 ? temp[2] : "";
  var d = new Date(temp[0] + "/" + temp[1] + "/" + year);
  return (
    d &&
    d.getMonth() + 1 == temp[0] &&
    d.getDate() == Number(temp[1]) &&
    d.getFullYear() == Number(temp[2])
  );
}
</script>
