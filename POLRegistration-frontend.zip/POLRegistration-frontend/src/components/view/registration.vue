<template>
  <section class="page-wrap authentication-page" padding>
    <div class="title">
      <h2>Welcome to Primerica Online Registration</h2>
    </div>
    <v-form @submit.prevent="submitForm">
      <section class="form-wrap">
        <div class="form-row">
          <div class="sub-title">
            <p>Please enter your email address so that we can identify you.</p>
          </div>
        </div>
        <div class="pb-3">
          <div>
            <h3>Rep ID / User ID</h3>
            <h4>{{ reg_form.userId }}</h4>
          </div>
        </div>
        <div class="form-row form-height">
          <v-text-field
            label="Non-Primerica Email Address"
            id="email"
            maxlength="100"
            oncopy="return false"
            onpaste="return false"
            :appendIcon="setIconEmail()"
            @input="setEmail()"
            v-model="$v.form.emailId.$model"
            @blur="$v.form.emailId.$touch()"
            :success="
              $v.form.emailId.email &&
                $v.form.emailId.required &&
                $v.form.emailId.checkPrimerica
            "
            :error="
              (!$v.form.emailId.required ||
                !$v.form.emailId.email ||
                !$v.form.emailId.checkPrimerica) &&
                $v.form.emailId.$dirty
            "
          >
          </v-text-field>
          <div class="error-grp">
            <div
              class="error"
              v-if="!$v.form.emailId.required && $v.form.emailId.$dirty"
            >
              An email address is required
            </div>
            <div
              class="error"
              v-if="!$v.form.emailId.email && $v.form.emailId.$dirty"
            >
              The email address entered is not valid
            </div>
            <div
              class="error"
              v-if="!$v.form.emailId.checkPrimerica && $v.form.emailId.$dirty"
            >
              Cannot enter @primerica.com email address
            </div>
          </div>
        </div>
        <div class="form-row form-height">
          <v-text-field
            label="Confirm Email Address"
            id="confirmemail"
            maxlength="100"
            oncopy="return false"
            onpaste="return false"
            @input="setConfirmEmail()"
            :appendIcon="setConfirmIconEmail()"
            v-model="$v.form.confirmemailId.$model"
            @blur="$v.form.confirmemailId.$touch()"
            :success="
              bothEmailMatch() &&
                $v.form.confirmemailId.email &&
                $v.form.confirmemailId.required &&
                $v.form.confirmemailId.checkPrimerica
            "
            :error="
              (!$v.form.confirmemailId.required ||
                !$v.form.confirmemailId.email ||
                !$v.form.confirmemailId.checkPrimerica ||
                !bothEmailMatch()) &&
                $v.form.confirmemailId.$dirty
            "
          >
          </v-text-field>
          <div class="error-grp">
            <div
              class="error"
              v-if="
                !$v.form.confirmemailId.required &&
                  $v.form.confirmemailId.$dirty
              "
            >
              An email address is required
            </div>
            <div
              class="error"
              v-if="
                !$v.form.confirmemailId.email && $v.form.confirmemailId.$dirty
              "
            >
              Enter a valid Email address
            </div>
            <div
              class="error"
              v-if="
                !$v.form.confirmemailId.checkPrimerica &&
                  $v.form.confirmemailId.$dirty
              "
            >
              Cannot enter @primerica.com email address
            </div>
            <div
              class="error"
              v-else-if="
                !bothEmailMatch() &&
                  $v.form.confirmemailId.required &&
                  $v.form.confirmemailId.email
              "
            >
              Those email addresses didn't match. Try again
            </div>
          </div>
        </div>
        <div class="form-row">
          <div class="btn-wrap">
            <v-btn
              class="btn btn-primary primary-color"
              @click.prevent="submitForm"
              :disabled="$v.form.$invalid || !formValid()"
              >Next</v-btn
            >
            <CancelButtonComponent
              :btnName="`Cancel`"
              :cancelCategory="`2FAreg`"
            />
          </div>
        </div>
      </section>
    </v-form>
    <div class="align-center footer-link">
      <a @click="redirectToApplication">Already have a POL account?</a>
    </div>
    <FooterComponent />
    <LoaderComponent v-if="dataload" />
  </section>
</template>

<script>
import { required, email } from "vuelidate/lib/validators";
import FooterComponent from "@/components/footer-component";
import LoaderComponent from "@/components/loader-component";
import CancelButtonComponent from "@/components/cancel-component";
import Dna from "../../shared/deviceDna.js";
import { mapState, mapGetters, mapActions } from "vuex";
import Api from "../../shared/api";
import Gtm from "../../shared/gtm.js";

export default {
  components: {
    FooterComponent,
    LoaderComponent,
    CancelButtonComponent,
  },
  data: (vm) => ({
    masked: true,
    fMask: true,
    menu: false,
    modal: false,
    emailId: "",
    confirmemailId: "",
    form: {
      emailId: "",
      confirmemailId: "",
    },
    genericError: {
      type: "warning",
      message:
        "Unable to register you online. Please call (888) 737-2255 US or (905) 812-3520 Canada for assistance with your account.",
    },
    emailTaken: {
      type: "warning",
      message: "The information entered doesn't match our records.",
    },
    dataload: false,
    iconAppend: false,
  }),
  validations: {
    form: {
      emailId: {
        required,
        email,
        checkPrimerica,
      },
      confirmemailId: {
        required,
        email,
        checkPrimerica,
      },
    },
  },
  async created() {
    Gtm.gtmPageView("2FAreg");
    this.getSessionInfo();
  },
  computed: {
    ...mapState(["reg_form", "info_form", "select_user_form"]),
    ...mapGetters(["auth_params", "getApplicationSource"]),
    computedDateFormatted() {
      return this.formatDate(this.date);
    },
  },
  methods: {
    ...mapActions(["startBannerTimer", "verificationUser"]),
    getSessionInfo() {
      Api.getRequest("pol/session/info", { session: this.auth_params.session })
        .then((response) => {
          this.reg_form.userId = response.data.userId;
          this.reg_form.regType = response.data.regType;
        })
        .catch((error) => {
          Api.redirectToLogin(this.getApplicationSource)
        });
    },
    redirectToApplication() {
      var hostName = window.location.hostname;
      var hostEnv = hostName.split(".")[0];
      if (this.getApplicationSource === "PriApp") {
        window.parent.postMessage("PRIAPPLOGIN", "*");
      } else {
        window.open("https://" + hostEnv + ".primericaonline.com", "_self");
      }
    },
    bothEmailMatch() {
      return this.emailId === this.confirmemailId;
    },
    setEmail() {
      this.emailId = this.$v.form.emailId.$model.toLowerCase();
    },
    setConfirmEmail() {
      this.confirmemailId = this.$v.form.confirmemailId.$model.toLowerCase();
    },
    inputFocus() {
      this.iconAppend = true;
    },
    inputBlur() {
      this.iconAppend = false;
    },
    formValid() {
      return this.$v.form.emailId.checkPrimerica && this.bothEmailMatch();
    },
    async submitForm() {
      this.reg_form.emailId = this.form.emailId;
      Api.getRequest("pol/registration/api/verification/nonpriemail ", {
        nonPriEmail: this.form.emailId,
        session: this.auth_params.session,
        userId: this.reg_form.userId,
        deviceDna: await Dna.getDevice(),
        applicationSource: this.getApplicationSource,
      })
        .then(async (response) => {
          if (response.data.message == "regEmailAlreadyTaken") {
            Gtm.gtmClickEvent("event", "2FAreg", "error", "emailTaken");
            this.showBanner(this.emailTaken);
            this.dataload = false;
            return;
          }
          const verificationResponse = await this.verificationUser();
          if (!verificationResponse) {
            this.genericError = true;
            this.dataload = false;
            return;
          }
          this.reg_form.userId = this.info_form.userId;
          this.info_form.mobNumber = this.info_form.mobilePhoneNumber;
          this.startBannerTimer();
          this.setPageDestination('verify-info');
          this.$router.push({ name: "verify-info" });
        })
        .catch((error) => {
          this.showBanner(this.genericError);
        });
    },
    setIconEmail() {
      if (
        this.$v.form.emailId.email &&
        this.$v.form.emailId.required &&
        this.$v.form.emailId.checkPrimerica
      )
        return "check_circle";
      if (
        (!this.$v.form.emailId.required ||
          !this.$v.form.emailId.email ||
          !this.$v.form.emailId.checkPrimerica) &&
        this.$v.form.emailId.$dirty
      )
        return "error";
    },
    setConfirmIconEmail() {
      if (
        this.$v.form.confirmemailId.email &&
        this.$v.form.confirmemailId.required &&
        this.$v.form.confirmemailId.checkPrimerica &&
        this.bothEmailMatch()
      )
        return "check_circle";
      if (
        (!this.$v.form.confirmemailId.required ||
          !this.$v.form.confirmemailId.email ||
          !this.$v.form.confirmemailId.checkPrimerica ||
          !this.bothEmailMatch()) &&
        this.$v.form.confirmemailId.$dirty
      )
        return "error";
    },
  },
};

function checkPrimerica(value) {
  return !value.toLowerCase().includes("@primerica.com");
}
</script>
