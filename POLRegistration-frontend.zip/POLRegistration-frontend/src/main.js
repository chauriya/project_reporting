"use strict";
import "babel-polyfill";
import Vue from "vue";
import Vuetify from "vuetify";
import "./plugins/vuetify";
import Router from "vue-router";
import paths from "./router/paths";
import Vuelidate from "vuelidate";
import store from "./store/index";
import App from "./App.vue";
import "./assets/scss/main.scss";
import setupCollection from "../src/shared/deviceDna";
import i18n from "./i18n";
import { mapActions } from "vuex";
import Api from './shared/api';

Vue.config.productionTip = false;

Vue.use(Vuelidate);
Vue.use(Router);
Vue.use(setupCollection);
// Vue.use(Vuex);
Vue.use(Vuetify);

const router = new Router({
  scrollBehavior() {
    return new Promise((resolve) => {
      resolve({ x: 0, y: 0 });
    });
  },
  // base: 'registration',
  mode: "history",
  linkActiveClass: "active",
  routes: paths,
});

router.beforeEach((to, from, next) => {
  if (to.name != "registration" && from.name == null) {
    next({ path: "/registration" });
  } else if(store.getters['getPageDestination'] !== to.name) {
    Api.redirectToLogin(store.getters['getApplicationSource']);
  } else {
    next();
  }
});

Vue.mixin({
  methods: {
    ...mapActions(["showBanner", "setPageDestination"]),
  },
});
new Vue({
  store,
  router,
  i18n,
  render: (h) => h(App),
}).$mount("#app");
