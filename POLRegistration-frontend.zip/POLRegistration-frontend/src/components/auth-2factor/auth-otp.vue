<template>
  <section class="page-wrap authentication-page" padding>
    <div class="title">
      <h2>Protect Your Account with Two-Factor Authentication</h2>
    </div>
    <v-form @submit.prevent="confirmPwd">
      <section class="form-wrap">
        <div class="form-row">
          <div class="user-notes">
            <p>
              Please check your {{ protect_acc_form.authType }}
              <span v-if="protect_acc_form.authType == 'text'">messages</span>
              at <b>{{ verifyAt }}</b> for your verification code. Your code may
              take a few moments to arrive.This code expires after 15 minutes.
              If you enter the code in after the allotted time, you will need to
              request another code.
            </p>
          </div>
        </div>
        <div class="form-row no-margin align-center">
          <!-- <label for="otp" class="form-label p-b-15 w-100 d-block">Enter the Verification Code we sent to you.</label> -->
          <v-text-field
            id="otp"
            label="Enter your Verification Code"
            v-numericOnly
            maxlength="6"
            type="tel"
            v-model="$v.auth_otp_form.otp.$model"
            @blur="$v.auth_otp_form.otp.$touch()"
            :append-icon="icon"
            @input="checkOtp"
            :disabled="verifyInputIsDisabled"
            :error="
              (!$v.auth_otp_form.otp.required ||
                !$v.auth_otp_form.otp.only6Digit ||
                !resendCheck) &&
                $v.auth_otp_form.otp.$dirty || isAttempt
            "
            :success="
              $v.auth_otp_form.otp.required &&
                $v.auth_otp_form.otp.only6Digit &&
                resendCheck && !isAttempt
            "
          ></v-text-field>
          <div class="error-grp p-b-15">
            <div class="error" v-if="isAttempt" v-html="errorMessage"></div>
            <div
              class="error"
              v-if="
                !$v.auth_otp_form.otp.required &&
                  $v.auth_otp_form.otp.$dirty &&
                  resendCheck
              "
            >
              Verification Code Required
            </div>
            <div
              class="error"
              v-if="
                !$v.auth_otp_form.otp.only6Digit &&
                  $v.auth_otp_form.otp.required &&
                  $v.auth_otp_form.otp.$dirty
              "
            >
              Please enter a 6-digit Verification Code
            </div>
          </div>
        </div>
        <div class="user-notes p-b-15">
          <h6>
            Didn't receive one?
            <a
              :class="enablelink ? 'disabled-link' : ''"
              @click="resendOtp(enablelink)"
              >Resend Code</a
            >
          </h6>
          <h6>
            Please wait 25 seconds before trying to resend. <br />
            If sent by email, check your spam folder too.
          </h6>
        </div>
        <div class="user-notes p-b-15">
          <h6>
            You can also
            <a :class="enablelink ? 'disabled-link' : ''" @click="redirectTo()"
              >try another verification method</a
            >
            or call tech support at
            <a :href="'tel:8887372255'">(888) 737-2255</a> US.
          </h6>
        </div>
        <div class="form-row no-margin">
          <div class="checkbox-group">
            <v-checkbox
              v-model="checkbox1"
              :label="
                `Trusted device(not shared or public). Select this option if you're the only person who uses this device.`
              "
              @change="checkTrustedDevice()"
            ></v-checkbox>
          </div>
        </div>
        <div class="form-row">
          <div class="btn-wrap">
            <v-btn
              class="btn btn-primary primary-color"
              @click.prevent="confirmPwd"
              :disabled="$v.auth_otp_form.$invalid"
              >Next</v-btn
            >
            <CancelButtonComponent
              :btnName="`Cancel`"
              :cancelCategory="`2FAreg.code`"
            />
          </div>
        </div>
      </section>
    </v-form>
    <FooterComponent />
    <LoaderComponent v-if="dataload" />
    <ErrorComponent
      :modelError.sync="otpExpireError"
      header-info="Verification Code has expired."
      body-info="You may request a new code below."
      body-description=" Please give us at least 25 seconds to send your new code over to you."
      actionTitle="Request New Code"
      :onClose="resendOtp"
    />
    <ErrorComponent
      :modelError.sync="finalAttemptError"
      header-info="Verification Failed"
      body-info="The Verification Code entered was incorrect. After three failed attempts, you must request a new code below"
      body-description=" Please give us at least 25 seconds to send your new code."
      actionTitle="Request New Code"
      :onClose="resendOtp"
      :onCloseDialog="disableVerifyInput"
    />
    <ErrorComponent
      :modelError.sync="accountLocked"
      header-info="Verification Failed"
      body-info="The Verification Code entered was incorrect."
      body-description=" After multiple failed attempts, you are locked out.For additional support, check your email on file or call Tech Support for assistance at <a href='tel:8887372255'>(888) 737-2255</a> for US."
      :onCloseDialog="redirectToLogin"
    />
  </section>
</template>
<script>
import FooterComponent from "@/components/footer-component";
import ErrorComponent from "@/components/error-component";
import CancelButtonComponent from "@/components/cancel-component";
import LoaderComponent from "@/components/loader-component";
import Dna from "../../shared/deviceDna.js";
import { required, maxLength } from "vuelidate/lib/validators";
import { numericOnly } from "../../../src/directives/fieldDirectives";
import { mapState, mapGetters, mapActions } from "vuex";
import Api from "../../shared/api";
import { setTimeout } from "timers";
import Gtm from "../../shared/gtm.js";
export default {
  components: {
    FooterComponent,
    ErrorComponent,
    CancelButtonComponent,
    LoaderComponent,
  },
  data: () => ({
    checkbox1: false,
    verifyAt: "",
    only6Digit: false,
    auth_otp_form: {
      otp: "",
    },
    enablelink: true,
    dataload: false,
    genericError: {
      type: "warning",
      message:
        "Unable to register you online. Please call (888) 737-2255 US for assistance with your account.",
    },
    accountLocked: false,
    otpExpireError: false,
    finalAttemptError: false,
    errorMessages: [
      "The Verification Code entered was incorrect. You may re-enter the Verification Code two more times before you are locked out.",
      "<strong>The Verification Code entered was incorrect.</strong> You may re-enter the Verification Code once more before you are locked out.",
    ],
    errorMessage: "",
    isAttempt: false,
    resendCheck: true,
    verifyInputIsDisabled: false
  }),
  computed: {
    ...mapState(["info_form", "protect_acc_form", "reg_form", "auth_otp"]),
    ...mapGetters(["auth_params", "getApplicationSource"]),
    icon() {
      if (!this.$v.auth_otp_form.otp.$dirty) {
        return "";
      }
      return this.$v.auth_otp_form.otp.$invalid ? "error" : "check_circle";
    },
    otpSucessMessage() {
      let emailMessage =
        this.protect_acc_form.authType == "email"
          ? "Please check your spam folder or request a new Code if you don't receive it."
          : "";
      return `We've ${
        this.protect_acc_form.authType
      }ed your Verification Code to you. ${emailMessage}`;
    },
  },
  created() {
    this.auth_otp.trustDevice = this.checkbox1;
    Gtm.gtmPageView("2FAreg.code");
    this.verifyAt = this.protect_acc_form.authStatusMask;
    if (this.$route.params.otpSuccess == true) {
      this.showBanner({ type: "success", message: this.otpSucessMessage });
    }
    this.togglelink();
  },
  validations: {
    auth_otp_form: {
      otp: {
        required,
        only6Digit,
      },
    },
  },
  methods: {
    ...mapActions(["setAuthParams"]),
    togglelink() {
      this.enablelink = true;
      var vm = this;
      setTimeout(function() {
        vm.enablelink = false;
      }, 25000);
    },
    checkOtp() {
      this.resendCheck = true;
      if (this.auth_otp_form.otp == "") {
        this.isAttempt = false;
      }
    },
    onCloseError() {
      this.setPageDestination('registration');
      this.$router.push({ name: "registration" });
    },
    async confirmPwd() {
      Gtm.gtmClickEvent("event", "2FAreg.code", "click", "next");
      // otp api start
      this.dataload = true;
      var otpHead = {
        deviceDna: await Dna.getDevice(),
        "Content-Type": "application/json",
        email: this.protect_acc_form.authStatus,
        otp: this.auth_otp_form.otp,
        deviceid: localStorage.getItem("deviceid"),
        session: this.auth_params.session,
        userId: this.reg_form.userId,
        sourceKey: this.reg_form.userId,
        // userEmail: this.reg_form.emailId,
        applicationSource: this.getApplicationSource,
      };
      Api.postRequest("polregistration/users/mfa/verification/otp", otpHead)
        .then((response) => {
          Gtm.gtmClickEvent(
            "event",
            "2FAreg.code",
            "submitCode",
            "codeSuccess"
          );
          this.setAuthParams({ session: response.headers.session });
          let data = response.data;
          this.setPageDestination('terms-and-condition');
          this.$router.push({ name: "terms-and-condition" });
          this.dataload = false;
        })
        .catch((error) => {
          this.dataload = false;
          if (error.response.data.error.errorCode == 4002) {
            this.showBanner(this.genericError);
            this.isAttempt = false;
          } else if (error.response.data.error.errorCode == 4037) {
            this.otpExpireError = true;
          } else if (error.response.data.error.errorCode == 4230) {
            this.accountLocked = true;
            this.isAttempt = false;
          } else if (error.response.data.error.count == "3") {
            Gtm.gtmClickEvent(
              "event",
              "2FAreg.code",
              "submitCode",
              "codeFail3"
            );
            this.finalAttemptError = true;
            this.isAttempt = false;
          } else if (
            error.response.data.error.count == "2" ||
            error.response.data.error.count == "1"
          ) {
            if (error.response.data.error.count == "2") {
              Gtm.gtmClickEvent(
                "event",
                "2FAreg.code",
                "submitCode",
                "codeFail2"
              );
            }
            if (error.response.data.error.count == "1") {
              Gtm.gtmClickEvent(
                "event",
                "2FAreg.code",
                "submitCode",
                "codeFail1"
              );
            }
            this.isAttempt = true;
            this.errorMessage = this.errorMessages[
              parseInt(error.response.data.error.count) - 1
            ];
          } else {
            this.showBanner(this.genericError);
          }
        });
      // otp api end
    },
    async resendOtp(sendOtp = false) {
      if (sendOtp) {
        return true;
      }
      this.togglelink();
      Gtm.gtmClickEvent("event", "2FAreg.code", "link", "resendCode");
      // authOtp api start
      this.auth_otp_form.otp = "";
      this.verifyInputIsDisabled = false;
      this.otpExpireError = false;
      this.isAttempt = false;
      this.resendCheck = false;
      this.dataload = true;
      var authHead = {
        deviceDna: await Dna.getDevice(),
        "Content-Type": "application/json",
        deviceid: localStorage.getItem("deviceid"),
        session: this.auth_params.session,
        userId: this.reg_form.userId,
        applicationSource: this.getApplicationSource,
      };
      if (this.protect_acc_form.authType == "email") {
        var authBody = {
          firstName: this.info_form.firstName,
          email: this.protect_acc_form.authStatus,
          // userEmail: this.reg_form.emailId,
        };
      } else {
        var authBody = {
          phone: this.protect_acc_form.authStatus,
          // userEmail: this.reg_form.emailId,
          firstName: this.info_form.firstName,
        };
      }
      Api.postRequest("polregistration/users/mfa/otp", authHead, authBody)
        .then((response) => {
          let data = response.data;
          this.showBanner({ type: "success", message: this.otpSucessMessage });
          this.dataload = false;
        })
        .catch((error) => {
          this.dataload = false;
          if (error.response.data.error.errorCode == 4002) {
            this.accountLocked = true;
            this.isAttempt = false;
          } else {
            this.showBanner(this.genericError);
          }
        });
      // authOtp api end
    },
    checkTrustedDevice() {
      this.auth_otp.trustDevice = this.checkbox1;
    },
    redirectTo() {
      if (!this.enablelink) {
        this.setPageDestination('authentication');
        this.$router.push({ name: "authentication" });
      }
    },
     disableVerifyInput(){
      this.verifyInputIsDisabled = true;
      this.auth_otp_form.otp = '';
      this.$v.$reset()
    },
    redirectToLogin() {
      Api.redirectToLogin(this.getApplicationSource)
    }
  },
};
function only6Digit(value) {
  var re = /^(?:\d{6})$/; // Only 6 digit number
  if (value != "") {
    this.only6Digit = re.test(value);
  } else {
    this.only6Digit = false;
  }
  return re.test(value);
}
</script>
