<template>
    <section class="loader-wrap">
        <v-progress-circular
        indeterminate
        :size= "50"
        class= "white-color"
      ></v-progress-circular>
    </section>
</template>
