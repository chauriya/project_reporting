<template>
  <section class="page-wrap authentication-page" padding>
    <div class="title p-b-15">
      <h2>Set up your password to continue.</h2>
    </div>
    <section class="form-wrap">
      <form @submit.prevent="submitForm">
        <div class="form-row">
          <v-text-field
            id="pwd"
            label="Create a Password"
            class="form-hint"
            oncopy="return false"
            onpaste="return false"
            v-model="$v.password_setup_form.password.$model"
            :type="e3 ? 'password' : 'text'"
            @focus="passwordFocus()"
            @blur="passwordBlur()"
            @input="passwordInput()"
            :success="
              minMaxC &&
                !spacesExist &&
                noSameCharC &&
                lowerUpperCharC &&
                !restrictCharC &&
                passwordCharC &&
                atleast1digitCharC
            "
            :error="
              (!minMaxC ||
                spacesExist ||
                !noSameCharC ||
                !lowerUpperCharC ||
                restrictCharC ||
                !passwordCharC ||
                !atleast1digitCharC) &&
                !errorBlack
            "
          >
            <span slot="append">
              <v-icon
                class="toggle-masking primary-color"
                @click="toggleMasked"
                :class="iconAppend ? 'active' : ''"
                >{{ masked ? "visibility" : "visibility_off" }}</v-icon
              >
              <v-icon
                class="toggle-masking light-grey-color primary-color"
                :class="iconAppend ? 'active' : ''"
                v-if="
                  minMaxC &&
                    !spacesExist &&
                    noSameCharC &&
                    lowerUpperCharC &&
                    !restrictCharC &&
                    passwordCharC &&
                    atleast1digitCharC
                "
                >{{ "lock" }}</v-icon
              >
              <v-icon
                class="toggle-masking"
                :class="iconAppend ? 'active' : ''"
                v-if="passwordError"
                >{{ "error" }}</v-icon
              >
            </span>
          </v-text-field>
          <div class="user-notes-input user-notes">
            <h6
              class="dark-grey-color"
              :class="{
                'red-color': passwordError,
                'green-color': passwordSuccess,
              }"
            >
              Use 8 or more characters with mix of letters, numbers & symbols.
            </h6>
          </div>
          <div
            class="error-group"
            :class="{ error: passwordError, berror: passwordSuccess }"
            v-if="showPasswordError"
          >
            <div
              class="error"
              v-if="!minMax"
              :class="{ nerror: minMaxC, berror: errorBlack }"
            >
              <i
                class="fa"
                :class="minMaxC ? 'fa-check-circle' : ' fa-times-circle'"
                aria-hidden="true"
              ></i>
              Use 8 or more characters
            </div>
            <div class="error" v-if="validateSpaces()">
              <i class="fa fa-times-circle" aria-hidden="true"></i> Your
              password cannot have spaces
            </div>
            <div
              class="error"
              v-if="!atleast1digit"
              :class="{ nerror: atleast1digitCharC, berror: errorBlack }"
            >
              <i
                class="fa"
                :class="
                  atleast1digitCharC ? 'fa-check-circle' : ' fa-times-circle'
                "
                aria-hidden="true"
              ></i>
              Use a number (e.g. 1234)
            </div>
            <div class="error" v-if="validateSameChar()">
              <i class="fa fa-times-circle" aria-hidden="true"></i> Cannot
              contain more than two consecutive identical characters.
            </div>
            <div
              class="error"
              v-if="!lowerUpperChar"
              :class="{ nerror: lowerUpperCharC, berror: errorBlack }"
            >
              <i
                class="fa"
                :class="
                  lowerUpperCharC ? 'fa-check-circle' : ' fa-times-circle'
                "
                aria-hidden="true"
              ></i>
              Use upper and lowercase letter(e.g. Aa)
            </div>
            <div class="error" v-if="validateCharNotToUse()">
              <i class="fa fa-times-circle" aria-hidden="true"></i>Your password
              cannot contain certain special characters ( ‘ &lt; &gt; “ )
            </div>
            <div
              class="error"
              v-if="!passwordChar"
              :class="{ nerror: passwordCharC, berror: errorBlack }"
            >
              <i
                class="fa"
                :class="passwordCharC ? 'fa-check-circle' : ' fa-times-circle'"
                aria-hidden="true"
              ></i>
              Password cannot contain Rep ID
            </div>
            <div
              class="error nerror"
              v-else-if="
                minMax &&
                  !spacesExist &&
                  noSameCharC &&
                  lowerUpperChar &&
                  !restrictChar &&
                  passwordChar &&
                  atleast1digit &&
                  !spacesExist &&
                  !charNotToUse
              "
            >
              <i class="fa fa-check-circle" aria-hidden="true"></i> STRONG
              password created
            </div>
          </div>
        </div>
        <div class="form-row form-height">
          <v-text-field
            id="confirm-pwd"
            class="form-hint"
            oncopy="return false"
            onpaste="return false"
            label="Confirm Password"
            v-model="$v.password_setup_form.confirmPassword.$model"
            :type="e4 ? 'password' : 'text'"
            @blur="$v.password_setup_form.confirmPassword.$touch()"
            :success="
              $v.password_setup_form.confirmPassword.sameAsPassword &&
                $v.password_setup_form.confirmPassword.required
            "
            :error="
              (!$v.password_setup_form.confirmPassword.required ||
                !$v.password_setup_form.confirmPassword.sameAsPassword) &&
                $v.password_setup_form.confirmPassword.$dirty
            "
          >
            <span slot="append">
              <v-icon
                class="toggle-masking primary-color"
                @click="toggleConfirmMasked"
                :class="confirmIconAppend ? 'active' : ''"
                >{{ confirmmasked ? "visibility" : "visibility_off" }}</v-icon
              >
              <v-icon
                class="toggle-masking light-grey-color primary-color"
                :class="confirmIconAppend ? 'active' : ''"
                v-if="
                  $v.password_setup_form.confirmPassword.sameAsPassword &&
                    $v.password_setup_form.confirmPassword.required
                "
                >{{ "lock" }}</v-icon
              >
              <v-icon
                class="toggle-masking"
                :class="confirmIconAppend ? 'active' : ''"
                v-if="
                  (!$v.password_setup_form.confirmPassword.required ||
                    !$v.password_setup_form.confirmPassword.sameAsPassword) &&
                    $v.password_setup_form.confirmPassword.$dirty
                "
                >{{ "error" }}</v-icon
              >
            </span>
          </v-text-field>
          <div
            class="error"
            v-if="
              !$v.password_setup_form.confirmPassword.required &&
                $v.password_setup_form.confirmPassword.$dirty
            "
          >
            Confirmation of your password is required
          </div>
          <div
            class="error"
            v-if="
              $v.password_setup_form.confirmPassword.required &&
                !$v.password_setup_form.confirmPassword.sameAsPassword
            "
          >
            The password entered does not match
          </div>
        </div>
        <div class="form-row">
          <div class="btn-wrap">
            <v-btn
              class="btn btn-primary primary-color"
              @click.prevent="submitForm"
              :disabled="
                $v.password_setup_form.$invalid ||
                  !minMaxC ||
                  spacesExist ||
                  !noSameCharC ||
                  !lowerUpperCharC ||
                  restrictCharC ||
                  !passwordCharC
              "
              >Submit</v-btn
            >
            <CancelButtonComponent
              :btnName="`Cancel`"
              :cancelCategory="`2FAreg.setPw`"
            />
          </div>
        </div>
      </form>
    </section>
    <FooterComponent />
    <LoaderComponent v-if="dataload" />
    <ErrorComponent
      :modelError.sync="registeredError"
      header-info="We're sorry."
      body-info="The information entered was incorrect."
      body-description="Please try again or verify with your RVP that you have access."
    />
  </section>
</template>

<script>
import { mapState, mapGetters } from "vuex";
import {
  required,
  minLength,
  maxLength,
  sameAs,
} from "vuelidate/lib/validators";
import { helpers } from "vuelidate/lib/validators";
import ErrorComponent from "@/components/error-component";
import FooterComponent from "@/components/footer-component";
import CancelButtonComponent from "@/components/cancel-component";
import LoaderComponent from "@/components/loader-component";
import {
  getPlatform,
  getDeviceName,
  getDevicePlatform,
} from "../../shared/deviceDetect";
import Api from "../../shared/api";
import Dna from "../../shared/deviceDna.js";
import { setTimeout, clearTimeout } from "timers";
import Gtm from "../../shared/gtm.js";
const touchMap = new WeakMap();

export default {
  components: {
    FooterComponent,
    ErrorComponent,
    CancelButtonComponent,
    LoaderComponent,
  },
  data: () => ({
    errorBlack: true,
    e3: true,
    e4: true,
    genericError: {
      type: "warning",
      message:
        "Unable to register you online. Please call (888) 737-2255 US or (905) 812-3520 Canada for assistance with your account.",
    },
    registeredError: false,
    dataload: false,
    minMax: false,
    minMaxC: false,
    minMaxTO: "",
    alphaNum: false,
    alphaNumC: false,
    alphaNumTO: "",
    noSameChar: false,
    noSameCharC: false,
    no3SameCharTO: "",
    lowerUpperChar: false,
    lowerUpperCharC: false,
    lowerUpperCharTO: "",
    restrictChar: false,
    restrictCharC: false,
    restrictCharTO: "",
    passwordChar: false,
    passwordCharC: false,
    passwordCharTO: "",
    password_setup_form: {
      password: "",
      confirmPassword: "",
    },
    masked: true,
    iconAppend: true,
    passtoggle: true,
    confirmmasked: true,
    confirmIconAppend: true,
    confirmPasstoggle: true,
    showPasswordError: false,
    atleast1digit: false,
    atleast1digitCharC: false,
    atleast1digitCharTO: "",
    atleast1symbol: false,
    atleast1symbolC: false,
    atleast1symbolTO: "",
    emptyString: false,
    spacesExist: false,
    specialCharExist: false,
    errorFlag: true,
    hintColor: "red",
    charNotToUse: false,
  }),
  computed: {
    ...mapState([
      "reg_form",
      "info_form",
      "communication_form",
      "protect_acc_form",
      "auth_otp",
      "auth_params",
    ]),
    ...mapGetters(["getApplicationSource","hostName"]),
    passwordSuccess() {
      return (
        this.minMaxC &&
        !this.spacesExist &&
        this.noSameCharC &&
        this.lowerUpperCharC &&
        !this.restrictCharC &&
        this.passwordCharC &&
        this.atleast1digitCharC
      );
    },
    passwordError() {
      return (
        (!this.minMaxC ||
          this.spacesExist ||
          !this.noSameCharC ||
          !this.lowerUpperCharC ||
          this.restrictCharC ||
          !this.passwordCharC ||
          !this.atleast1digitCharC) &&
        !this.errorBlack
      );
    },
  },
  created: function() {
    Gtm.gtmPageView("2FAreg.setPw");
    Gtm.gtmBillOnFile(this.info_form.isBillingInfoAvailable);
  },
  validations: {
    password_setup_form: {
      password: {
        minMaxCheck,
        alphaNumNoSpace,
        no3SameChar,
        checkLowerUpperCase,
        charNotAllowed,
        checkPasswordVal,
        atleastOnedigit,
        atleastOneSymbol,
        emptySpaces,
        charNotToUse,
      },
      confirmPassword: {
        required,
        sameAsPassword: sameAs("password"),
      },
    },
  },
  methods: {
    async submitForm() {
      Gtm.gtmClickEvent("event", "2FAreg.setPw", "click", "next");
      this.dataload = true;
      var registeredHeader = {
        "Content-Type": "application/json",
        session: this.auth_params.session,
        TrustDevice: this.auth_otp.trustDevice,
        deviceid: localStorage.getItem("deviceid"),
        deviceDna: await Dna.getDevice(),
        deviceName: getDeviceName(),
        sourceKey: this.reg_form.userId,
        applicationSource: this.getApplicationSource,
        userId: this.reg_form.userId,
        gwUrl: this.hostName
      };
      var registeredBody = {
        password: this.password_setup_form.password,
        primericaEmail: this.communication_form.emailSuggest,
        regId: this.reg_form.userId,
        friendlyUserId: this.info_form.friendlyUserid,
        primaryCo: this.info_form.primaryCo,
        firstName: encodeURIComponent(this.info_form.firstName).replace(/'/g, "%27"),
        lastName: encodeURIComponent(this.info_form.lastName).replace(/'/g, "%27"),
        regType: this.reg_form.regType,
        ssn: this.reg_form.ssnSin,
        dob: this.reg_form.datestring,
        title: this.info_form.displayTitle,
        emailOptOut: this.communication_form.emailOptOut,
        // personalEmail: this.reg_form.emailId,
        personalEmail2Fa:
          this.protect_acc_form.authType == "email"
            ? this.protect_acc_form.authStatus
            : "",
        cellPhone2Fa:
          this.protect_acc_form.authType == "text"
            ? this.protect_acc_form.authStatus
            : "",
        entryType: this.info_form.appEntryType,
        srcPlatform: getDevicePlatform(this.getApplicationSource),
        verifyHash: {
          presentInCabCustomerUse: this.info_form.presentInCabCustomerUse,
          userDisconnected: this.info_form.userDisconnected,
          nfePaymentStatus: this.info_form.nfePaymentStatus,
          firstName: encodeURIComponent(this.info_form.firstName).replace(/'/g, "%27"),
          lastName: encodeURIComponent(this.info_form.lastName).replace(/'/g, "%27"),
          withinIBAPeriod: this.info_form.withinIBAPeriod,
          ibaExpireDt: this.info_form.ibaExpireDt,
          paidThruDate: this.info_form.paidThruDate,
          accountNum: this.info_form.accountNum,
          billDay: this.info_form.billDay,
        },
        serviceLevel: this.reg_form.serviceLevel,
        isInstantIssue: this.reg_form.instantIssueInd,
        precoded: this.reg_form.regType == "PRECODED" ? true : false,
        polEnabled: this.reg_form.regType == "PRECODED" ? "N" : "Y",
        deletePrecoded: this.reg_form.deletePrecoded,
        isRvp: this.info_form.isRvp,
      };
      Gtm.gtmClickEvent(
        "event",
        "2FAreg.setPw",
        this.auth_otp.trustDevice,
        "trustDevice"
      );
      if (this.reg_form.regType.toLowerCase() === "rep") {
        Api.postRequest(
          "pol/registration/api/rep",
          registeredHeader,
          registeredBody,
          { withCredentials: true }
        )
          .then((response) => {
            this.dataload = false;
            if (this.getApplicationSource === undefined) {
              var hostName = window.location.hostname;
              var hostEnv = hostName.split(".")[0];
              if (hostEnv == "localhost") {
                hostEnv = "dev";
              }
              if (this.info_form.isLifeLicensed || this.info_form.isRvp) {
                this.dataload = true;
                window.open(
                  "https://" +
                    hostEnv +
                    ".primericaonline.com/home/index_was35.html",
                  "_self"
                );
              } else {
                this.dataload = true;
                window.open(
                  "https://" +
                    hostEnv +
                    ".primericaonline.com/home/index_was35.html",
                  "_self"
                );
              }
            } else {
              window.parent.postMessage("PRIAPPLOGIN", "*");
            }
          })
          .catch((error) => {
            this.dataload = false;

            if (
              error.response.status === 500 &&
              error.response.data.statusMessage === "REPAlreadyRegistered"
            ) {
              this.registeredError = true;
            } else {
              this.showBanner(this.genericError);
            }
          });
      } else if (this.reg_form.regType.toLowerCase() === "office_user") {
        Api.postRequest(
          "pol/registration/api/officeuser",
          registeredHeader,
          registeredBody,
          { withCredentials: true }
        )
          .then((response) => {
            this.dataload = false;
            if (this.getApplicationSource === undefined) {
              var hostName = window.location.hostname;
              var hostEnv = hostName.split(".")[0];
              if (hostEnv == "localhost") {
                hostEnv = "dev";
              }
              if (this.info_form.isLifeLicensed || this.info_form.isRvp) {
                this.dataload = true;
                window.open(
                  "https://" +
                    hostEnv +
                    ".primericaonline.com/home/index_was35.html",
                  "_self"
                );
              } else {
                this.dataload = true;
                window.open(
                  "https://" +
                    hostEnv +
                    ".primericaonline.com/home/index_was35.html",
                  "_self"
                );
              }
            } else {
              window.parent.postMessage("PRIAPPLOGIN", "*");
            }
          })
          .catch((error) => {
            this.dataload = false;
            if (
              error.response.status === 500 &&
              error.response.data.statusMessage ===
                "OfficeUserAlreadyRegistered"
            ) {
              this.registeredError = true;
            } else {
              this.showBanner(this.genericError);
            }
          });
      }
    },
    toggleMasked() {
      this.e3 = !this.e3;
      this.masked = !this.masked;
      this.passtoggle = !this.passtoggle;
    },
    toggleConfirmMasked() {
      this.e4 = !this.e4;
      this.confirmmasked = !this.confirmmasked;
      this.confirmPasstoggle = !this.confirmPasstoggle;
    },
    passwordFocus: function() {
      if (
        this.$v.password_setup_form.password.$model == "" &&
        this.errorBlack
      ) {
        this.showPasswordError = true;
        this.errorBlack = true;
      } else {
        this.errorBlack = false;
      }
    },
    passwordBlur: function() {
      if (
        this.$v.password_setup_form.password.$model == "" &&
        this.errorBlack
      ) {
        this.errorBlack = false;
        this.showPasswordError = true;
      }
    },
    passwordInput: function() {
      if (this.$v.password_setup_form.password.$model != "") {
        this.errorBlack = false;
      }
    },
    validatePassword() {
      return !(
        this.minMax &&
        this.alphaNum &&
        this.noSameChar &&
        this.lowerUpperChar &&
        !this.restrictChar &&
        this.passwordChar &&
        this.atleast1symbolC
      );
    },
    validateSpaces() {
      if (this.spacesExist) {
        return true;
      } else {
        return false;
      }
    },
    validateCharNotToUse() {
      if (this.charNotToUse) {
        return true;
      } else {
        return false;
      }
    },
    validateSameChar() {
      if (this.noSameCharC) {
        return false;
      } else {
        return true;
      }
    },
  },
};

function minMaxCheck(value) {
  var re = /^.{8,64}$/; //check number of digit between 8-64
  if (value != "" && re.test(value)) {
    this.minMaxC = re.test(value);
    if (this.minMaxTO) {
      clearTimeout(this.minMaxTO);
      this.minMaxTO = null;
    }
    this.minMaxTO = setTimeout(() => {
      this.minMax = true;
    }, 1000);
  } else {
    clearTimeout(this.minMaxTO);
    this.minMax = false;
    this.minMaxC = false;
  }
  return true;
}

function alphaNumNoSpace(value) {
  var re = /^(?=.*[0-9])(?=.*[a-zA-Z])([a-zA-Z0-9!@#$%^&*(),.?`~+-=_":{};|]+)$/; // checks alpha numberic without space
  if (value != "" && re.test(value)) {
    this.alphaNumC = re.test(value);
    if (this.alphaNumNoSpaceTO) {
      clearTimeout(this.alphaNumNoSpaceTO);
      this.alphaNumNoSpaceTO = null;
    }
    this.alphaNumNoSpaceTO = setTimeout(() => {
      this.alphaNum = true;
    }, 1000);
  } else {
    clearTimeout(this.alphaNumNoSpaceTO);
    this.alphaNum = false;
    this.alphaNumC = false;
  }
  return true;
}

function checkLowerUpperCase(value) {
  var re = /(?=.*[a-z])(?=.*[A-Z]).*/; // checks lower and uppercase
  if (value != "" && re.test(value)) {
    this.lowerUpperCharC = re.test(value);
    if (this.checkLowerUpperCaseTO) {
      clearTimeout(this.checkLowerUpperCaseTO);
      this.checkLowerUpperCaseTO = null;
    }
    this.checkLowerUpperCaseTO = setTimeout(() => {
      this.lowerUpperChar = true;
    }, 1000);
  } else {
    clearTimeout(this.checkLowerUpperCaseTO);
    this.lowerUpperChar = false;
    this.lowerUpperCharC = false;
  }
  return true;
}

function no3SameChar(value) {
  var re = /^.*(\S)(?: ?\1){2}.*$/; // checks no consecutive 3 same characters
  if (value) {
    if (!re.test(value)) {
      this.noSameCharC = !re.test(value);
      if (this.no3SameCharTO) {
        clearTimeout(this.no3SameCharTO);
        this.no3SameCharTO = null;
      }
      this.no3SameCharTO = setTimeout(() => {
        this.noSameChar = !re.test(value);
      }, 1000);
    } else {
      clearTimeout(this.no3SameCharTO);
      this.noSameChar = false;
      this.noSameCharC = false;
    }
  } else {
    this.noSameChar = true;
    this.noSameCharC = true;
  }
  return true;
}

function charNotAllowed(value) {
  var re = /(['"<>])/; // checks ' ' " " < > chars allowed
  if (value != "" && re.test(value)) {
    this.restrictCharC = re.test(value);
    if (this.charNotAllowedTO) {
      clearTimeout(this.charNotAllowedTO);
      this.charNotAllowedTO = null;
    }
    this.charNotAllowedTO = setTimeout(() => {
      this.restrictChar = true;
    }, 1000);
  } else {
    clearTimeout(this.charNotAllowedTO);
    this.restrictChar = false;
    this.restrictCharC = false;
  }
  return true;
}

function checkPasswordVal(value) {
  var checkUserId = !value
    .toLowerCase()
    .includes(this.reg_form.userId.toLowerCase());
  if (value != "" && checkUserId) {
    this.passwordCharC = true;
    if (this.passwordCharTO) {
      clearTimeout(this.passwordCharTO);
      this.passwordCharTO = null;
    }
    this.passwordCharTO = setTimeout(() => {
      this.passwordChar = true;
    }, 1000);
  } else {
    clearTimeout(this.passwordCharTO);
    this.passwordChar = false;
    this.passwordCharC = false;
  }
  return true;
}

function atleastOnedigit(value) {
  var re = /([0-9])/; // checks for atleast one digit from 0 to 9
  if (value && re.test(value)) {
    this.atleast1digitCharC = re.test(value);
    if (this.atleast1digitCharTO) {
      clearTimeout(this.atleast1digitCharTO);
      this.atleast1digitCharTO = null;
    }
    this.atleast1digitCharTO = setTimeout(() => {
      this.atleast1digit = true;
    }, 1000);
  } else {
    clearTimeout(this.atleast1digitCharTO);
    this.atleast1digit = false;
    this.atleast1digitCharC = false;
  }
  return true;
}

function atleastOneSymbol(value) {
  var re = /([;&!@#$%^*(),.?:{}|])/; // checks for atleast one digit from 0 to 9
  if (value && re.test(value)) {
    this.atleast1symbolC = re.test(value);
    if (this.atleast1symbolTO) {
      clearTimeout(this.atleast1symbolTO);
      this.atleast1symbolTO = null;
    }
    this.atleast1symbolTO = setTimeout(() => {
      this.atleast1symbol = true;
    }, 1000);
  } else {
    clearTimeout(this.atleast1symbolTO);
    this.atleast1symbol = false;
    this.atleast1symbolC = false;
  }
  return true;
}
function emptySpaces(value) {
  var re = /\s/; // checks for spaces
  if (value && re.test(value)) {
    this.spacesExist = true;
  } else {
    this.spacesExist = false;
  }
  return true;
}

function charNotToUse(value) {
  var re = /(['"<>])/;
  if (value && re.test(value)) {
    this.charNotToUse = true;
  } else {
    this.charNotToUse = false;
  }
  return true;
}
</script>
