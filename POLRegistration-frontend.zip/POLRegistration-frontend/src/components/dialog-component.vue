<template>
  <v-layout row justify-center>
    <v-dialog v-model="modelDialog" persistent max-width="320">
      <v-card>
        <v-card-title class="headline">{{ headerInfo }}</v-card-title>
        <v-card-text class="error-dec">
          <p>{{ bodyInfo }}</p>
        </v-card-text>
        <v-card-actions>
          <v-spacer></v-spacer>
          <v-btn color="btn-primary primary-color" text @click.native="close"
            >Ok</v-btn
          >
        </v-card-actions>
      </v-card>
    </v-dialog>
  </v-layout>
</template>
<script>
export default {
  props: {
    modelDialog: {
      default: false,
    },
    headerInfo: "",
    bodyInfo: "",
  },
  mounted() {},
  created() {},
  methods: {
    close() {
      this.$emit("update:modelDialog", false);
      this.setPageDestination('registration');
      this.$router.push({ name: "registration" });
    },
  },
};
</script>
<style></style>
