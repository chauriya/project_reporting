import Vue from "vue";
import axios from "axios";
import VueAxios from "vue-axios";
import store from "@/store"
axios.defaults.withCredentials = true;
Vue.use(VueAxios, axios);
axios.interceptors.response.use((response) => {
  if (response.headers && response.headers.deviceid) {
    window.localStorage.setItem('deviceid', response.headers.deviceid);
  }
  return response
})
// var hostName = window.location.hostname;
// var hostEnv = hostName.split(".")[0];
// var Env = "gtw"
// if (hostEnv == "localhost") {
//   Env = "gtwd";
// }
// if (hostEnv == "drs") {
//   Env = "gtwt";
// }
// if (hostEnv == "dev" || hostEnv == "test") {
//   Env = "gtw" + hostEnv[0];
// }

// var baseUrl = "https://" + Env + ".primericaonline.com/";
//comment

export default {
  async getHostName(){
    try {
      if(store.getters.hostName != '') {
        return store.getters.hostName;
      }
      let hostName = window.location.hostname;
      const hostEnv = hostName.split(".")[0];
      const response = await axios.get('/polapps/rest/services/s/utility/serverenvironmentlookup');
      hostName = hostEnv == 'ool' ? response.data.outOfLoopGatewayHostName : response.data.gatewayHostName;
      // hostName = hostEnv == 'localhost' ? 'https://gtwd.primericaonline.com': hostName;
      store.dispatch('setHostName', hostName);
      return hostName;
    } catch(error){
      this.redirectToLogin();
    }
  },
  async getRequest(url, headers, params) {
    const baseUrl = await this.getHostName();
    return axios.get(`${baseUrl}/${url}`, {
      headers: headers,
      params: params,
    });
  },
  async postRequest(url, headers, body) {
    const baseUrl = await this.getHostName();
    return axios.post(`${baseUrl}/${url}`, body, {
      headers: headers,
    });
  },
  redirectToLogin(getApplicationSource) {
    var hostName = window.location.hostname;
    var hostEnv = hostName.split(".")[0];
    // hostEnv = hostEnv == 'www' ? '' : hostEnv + '.'
    if (hostEnv == "localhost") {
      window.open("/registration", "_self");
      return
    }
    if (getApplicationSource === "PriApp") {
      window.parent.postMessage("PRIAPPLOGIN", "*");
    } else {
      window.open(`https://${hostEnv}.primericaonline.com`, "_self");
    }
  }
};
