<template>
  <div class="wrap mt-5" :class="attributes.wrapClass" v-if="bannerShow">
    <div class="wrap-icon" :class="attributes.iconClass">
      <v-icon size="24" :class="attributes.iconClass">
        {{ attributes.icon }}
      </v-icon>
    </div>
    <div class="wrap-msg">
      <p v-html="bannerComponent.message"></p>
    </div>
    <v-spacer></v-spacer>
    <div class="wrap-close">
      <span>
        <v-icon size="24" color="black" right @click.native="close"
          >close</v-icon
        >
      </span>
    </div>
  </div>
</template>
<script>
import { mapGetters, mapActions } from "vuex";

export default {
  name: "banner-component",
  computed: {
    ...mapGetters(["bannerComponent", "bannerShow"]),
    attributes() {
      let attributes = {
        wrapClass: "success-wrap",
        iconClass: "success-icon-wrap",
        icon: "check_circle",
      };
      if (this.bannerComponent.type === "error") {
        attributes = {
          wrapClass: "error-wrap",
          iconClass: "error-icon-wrap",
          icon: "error",
        };
      } else if (this.bannerComponent.type === "warning") {
        attributes = {
          wrapClass: "warning-wrap",
          iconClass: "warning-icon-wrap",
          icon: "warning",
        };
      }
      return attributes;
    },
  },
  methods: {
    ...mapActions(["hideBanner"]),
    close() {
      this.hideBanner();
      this.bannerComponent.onClose();
    },
  },
};
</script>
