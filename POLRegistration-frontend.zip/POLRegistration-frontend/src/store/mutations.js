export const updateRegForm = (state, value) => {
  state.reg_form = value;
};
export const updateInfoForm = (state, value) => {
  state.info_form = value;
};
export const updateAuthStep1Form = (state, value) => {
  state.protect_acc_form = value;
};
export const updateOtpForm = (state, value) => {
  state.auth_otp_form = value;
};
export const setAuthParams = (state, value) => {
  state.auth_params = { ...state.auth_params, ...value };
};

export const setViewRegistration = (state, value) => {
  state.ui.viewRegistration = value;
};

export const changeSessionDialog = (state, value) => {
  state.ui.sessionDialog = value;
};

export const setDialogTimer = (state, value) => {
  state.ui.sessionTimer.dialog = value;
};
export const setApplicationSource = (state, value) => {
  state.ui.applicationSource = value;
};

export const setInfoForm = (state, value) => {
  state.info_form = { ...value };
};

export const resetState = (state) => {
  Object.keys(state).forEach((key) => {
    Object.keys(state[key]).forEach((subKey) => {
      if (typeof state[key][subKey] == "object") {
        state[key][subKey] = [];
      } else {
        state[key][subKey] = "";
      }
    });
  });
};

export const showBanner = (
  state,
  { type = "", message = "", onClose = () => 1 }
) => {
  state.ui.bannerComponent.type = type;
  state.ui.bannerComponent.message = message;
  state.ui.bannerComponent.onClose = onClose;
  state.ui.bannerComponent.show = type !== "" ? true : false;
};

export const setBannerTimer = (state, value) => {
  state.ui.bannerTimer = value;
};

export const hideBanner = (state) => {
  state.ui.bannerComponent = { ...state.ui.bannerComponent, show: false };
};

export const setPageDestination = (state, value) => {
  state.ui.pageDestination = value
};
export const setHostName = (state, value) => {
  state.hostName = value
};