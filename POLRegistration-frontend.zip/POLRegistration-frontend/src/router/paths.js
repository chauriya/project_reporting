export default [

    // {
    //     path: '/',
    //     meta: { title: 'Registration' },
    //     name: 'Root',
    //     redirect: {
    //         name: 'registration'
    //     },
    //     params: {
    //         navigate: true
    //     }
    // }, 
    {
        path: '/registration',
        meta: { title: 'Registration', prev: null, next: "verify-info" },
        name: 'registration',
        component: () => import(
            `../components/view/reg-switch`
        )
    }, 
    {
        path: '/verify-info',
        meta: { title: 'Verify Your Info', prev: 'registration', next: "communication"},
        name: 'verify-info',
        component: () => import(
            `../components/view/verify-info`
        )
    }, 
    {
        path: '/registration/communication',
        meta: { title: 'Contact Information', prev: 'verify-info', next: "authentication" },
        name: 'communication',
        component: () => import(
            `../components/view/communication`
        )
    }, 
    {
        path: '/authentication',
        meta: { title: 'Protect Your Account', prev: 'communication', next: "auth-otp" },
        name: 'authentication',
        component: () => import(
            `../components/auth-2factor/protect-your-acc`
        )
    }, 
    {
        path: '/auth-otp',
        meta: { title: 'Protect Your Account', prev: 'authentication', next: "terms-and-condition"  },
        name: 'auth-otp',
        component: () => import(
            `../components/auth-2factor/auth-otp`
        )
    }, 
    {
        path: '/password-setup',
        meta: { title: 'Password Setup', prev: 'terms-and-condition', next: null },
        name: 'password-setup',
        component: () => import(
            `../components/auth-2factor/password-setup`
        )
    }, 
    {
        path: '/terms-and-condition',
        meta: { title: 'Subscription Agreement', prev: 'auth-otp', next: "password-setup" },
        name: 'terms-and-condition',
        component: () => import(
            `../components/view/terms-condition`
        )
    }
]