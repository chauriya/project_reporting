<template>
  <div>
    <Layout :title="titleName"></Layout>
  </div>
</template>

<script>
import Layout from "./components/Layout";
export default {
  name: "App",
  data: () => {
    return {
      titleName: "",
      dialog: true,
    };
  },
  created() {},
  mounted() {
    window.addEventListener("unload", this.goToRoot);
  },
  beforeDestroy() {
    window.addEventListener("unload", this.goToRoot);
  },
  watch: {
    $route(to) {
      this.titleName = to.meta.title || "";
    },
  },
  methods: {
    goToRoot() {
      this.setPageDestination('registration');
      this.$router.replace({ name: "registration" });
    },
  },
  components: {
    Layout,
  },
};
</script>
