<template>
  <footer class="footer-wrap">
    <div class="logo">
      <h6>Primerica Online</h6>
    </div>
    <div class="footer-list">
      <ul>
        <li>
          <a
            @click="
              postLink(
                'http://www.primerica.com/public/privacy/primericaonline_and-primerica-app_privacy_policy.html'
              )
            "
            >Privacy</a
          >
        </li>
        <!-- <li><a >Privacy &amp; Security</a></li> -->
        <li>
          <a
            @click="
              postLink('https://www.primericaonline.com/NAPOLWelcome/public/agreements.html')
            "
            >Terms</a
          >
        </li>
      </ul>
    </div>
    <div class="copy-right">
      &copy; {{ getCurrentYear() }} Primerica
      <a @click="postLink('https://www.primericaonline.com')"
        >www.primericaonline.com</a
      >
    </div>
  </footer>
</template>

<script>
import { mapGetters } from "vuex";
export default {
  computed: {
    ...mapGetters(["getApplicationSource"]),
  },
  methods: {
    getCurrentYear() {
      const date = new Date();
      return date.getFullYear();
    },
    postLink(url) {
      if (this.getApplicationSource === "PriApp") {
        var message = {
          name: "PRIAPPOPENWINDOW",
          childData: {
            url,
          },
        };
        window.parent.postMessage(message, "*");
      } else {
        window.open(url, "_system");
      }
    },
  },
};
</script>

<style lang="stylus" scoped>
a:hover
  text-decoration: underline
</style>
