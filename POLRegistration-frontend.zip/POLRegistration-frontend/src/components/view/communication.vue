<template>
  <section class="page-wrap billing-page" padding>
    <div class="title communication-title">
      <h3>Primerica Email Address</h3>
    </div>
    <div class="user-notes pb-2">
      <p>Select your Primerica Business email.</p>
    </div>
    <v-form @submit.prevent="authStep1">
      <section class="form-wrap">
        <div class="form-row">
          <v-select
            :items="communication_form.emailSuggestData"
            v-model="communication_form.emailSuggest"
            @blur="$v.communication_form.emailSuggest.$touch()"
            @change="validateEmail()"
            label="Select One"
          ></v-select>
          <div class="error-grp">
            <div
              class="error"
              v-if="
                !$v.communication_form.emailSuggest.required &&
                  $v.communication_form.emailSuggest.$dirty
              "
            >
              Required
            </div>
            <div
              class="error"
              v-if="emailTakenFlag && $v.communication_form.emailSuggest.$dirty"
            >
              A Primerica Online account with this email address already exists
            </div>
          </div>
        </div>
        <!-- <div class="form-row">
          <div class="account-block m-b-10">
            <div class="user-info p-0 m-0">
              <h4>Non-Primerica Email Address</h4>
              <h5 class="f-18">{{ reg_form.emailId }}</h5>
            </div>
          </div>
        </div> -->
        <!-- <div class="form-row mobile-info">
          <v-text-field
            id="mob-number"
            label="Mobile Phone Number"
            mask="phone"
            type="tel"
            :disabled="true"
            v-model="communication_form.mobNumber"
            @blur="$v.communication_form.mobNumber.$touch()"
            :append-icon="icon"
            :success="mobileNumberCheck()"
            :error="
              !$v.communication_form.mobNumber.mobileNum &&
                $v.communication_form.mobNumber.$dirty
            "
          ></v-text-field>
          <div class="error-grp">
            <div
              class="error"
              v-if="
                !$v.communication_form.mobNumber.mobileNum &&
                  $v.communication_form.mobNumber.$dirty
              "
            >
              Please enter a 10-digit phone number.
            </div>
          </div>
          <div class="user-notes-input">
            <h6>
              We ask for your phone number to help verify your identity in case
              you forget your Rep ID or password.
            </h6>
          </div>
          <div class="user-notes">
            <h6>
              The above information will be used for Primerica-related
              communications, including two-factor authentication.
            </h6>
          </div>
        </div> -->
        <div class="form-row">
          <div class="btn-wrap">
            <v-btn
              class="btn btn-primary primary-color"
              @click.prevent="authStep1"
              :disabled="$v.communication_form.$invalid || this.emailTakenFlag"
              >Next</v-btn
            >
            <CancelButtonComponent
              :btnName="`Cancel`"
              :cancelCategory="`2FAreg.com`"
            />
          </div>
        </div>
      </section>
    </v-form>
    <FooterComponent />
    <LoaderComponent v-if="dataload" />
  </section>
</template>

<script>
import FooterComponent from "@/components/footer-component";
import LoaderComponent from "@/components/loader-component";
import CancelButtonComponent from "@/components/cancel-component";
import { required, email } from "vuelidate/lib/validators";
import { mapState, mapGetters } from "vuex";
import Api from "../../shared/api";
import Gtm from "../../shared/gtm.js";
import Dna from "../../shared/deviceDna.js";

export default {
  components: {
    FooterComponent,
    LoaderComponent,
    CancelButtonComponent,
  },
  data: () => ({
    genericError: {
      type: "warning",
      message:
        "Unable to register you online. Please call (888) 737-2255 US or (905) 812-3520 Canada for assistance with your account.",
    },
    emailTakenFlag: false,
    dataload: true,
  }),
  validations: {
    communication_form: {
      emailSuggest: {
        required,
      },
      mobNumber: {
        mobileNum,
      },
    },
  },
  computed: {
    ...mapState(["communication_form", "reg_form", "info_form", "auth_params"]),
    ...mapGetters(["getApplicationSource"]),

    icon() {
      if (
        !this.$v.communication_form.mobNumber.$dirty ||
        this.$v.communication_form.mobNumber.$model === ""
      ) {
        return "";
      }
      return this.$v.communication_form.mobNumber.mobileNum
        ? "check_circle"
        : "error";
    },
  },
  async created() {
    Gtm.gtmPageView("2FAreg.comms");
    window.addEventListener("beforeunload", this.someMethod);
    window.addEventListener("unload", function(event) {});
    this.communication_form.mobNumber = this.info_form.mobNumber;
    if (this.communication_form.mobNumber == "0000000000") {
      this.communication_form.mobNumber = "";
    }
    if (!this.communication_form.mobNumber) {
      this.communication_form.mobNumber = "";
    }

    // emailaddressesreg api start
    var emailaddressesregHead = {
      userId: this.reg_form.userId,
      verifyFirstName: this.info_form.firstName,
      verifyLastName: this.info_form.lastName,
      regType: this.reg_form.regType,
      session: this.auth_params.session,
      deviceid: localStorage.getItem("deviceid"),
      deviceDna: await Dna.getDevice(),
      sourceKey: this.reg_form.userId,
      "Content-Type": "application/json",
      applicationSource: this.getApplicationSource,
    };
    Api.getRequest("pol/registration/api/emailaddresses", emailaddressesregHead)
      .then((response) => {
        this.communication_form.emailSuggestData = [];
        this.communication_form.emailSuggest = "";
        for (var i = 0; i < response.data.emailAddresses.length; i++) {
          this.communication_form.emailSuggestData.push(
            response.data.emailAddresses[i].email
          );
        }
        this.dataload = false;
      })
      .catch((error) => {
        this.dataload = false;
        this.showBanner(this.genericError);
      });
  },
  methods: {
    mobileNumberCheck() {
      if (
        this.$v.communication_form.mobNumber.$model !== "" &&
        this.$v.communication_form.mobNumber.mobileNum
      )
        return true;
      else return false;
    },
    someMethod() {},
    authStep1() {
      Gtm.gtmClickEvent("event", "2FAreg.com", "click", "next");
      this.setPageDestination('authentication');
      this.$router.push({ name: "authentication" });
    },
    async validateEmail() {
      var friendlyIdHeader = {
        id: this.communication_form.emailSuggest,
        idType: "priemail",
        session: this.auth_params.session,
        deviceid: localStorage.getItem("deviceid"),
        deviceDna: await Dna.getDevice(),
        sourceKey: this.reg_form.userId,
        userId: this.reg_form.userId,
        applicationSource: this.getApplicationSource,
      };
      Api.getRequest(
        "pol/registration/api/availability",
        friendlyIdHeader
      ).then((response) => {
        this.emailTakenFlag = response["data"]["priEmailIdTaken"];
      });
      // });
    },
  },
};
function mobileNum(value) {
  var re = /^(?!(\d)\1+\b|1234567890)\d{10}$/; // Only 10 digit number
  if (value != "") {
    this.mobileNum = re.test(value);
  } else {
    this.mobileNum = true;
    return true;
  }
  return re.test(value);
}
</script>
<style scoped>
.v-messages {
  min-height: 0px !important;
}
</style>
