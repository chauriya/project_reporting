<template>
  <section class="page-wrap authentication-page" padding>
    <div class="title">
      <h2>Protect Your Account with Two-Factor Authentication</h2>
    </div>
    <v-form @submit.prevent="authOtp">
      <section class="form-wrap">
        <div class="form-row p-b-15">
          <div class="sub-title">
            <p>Choose how you would like to receive your Verification Code.</p>
          </div>
        </div>
        <div class="form-row">
          <div class="radio-group" :class="{ 'multiple-grp': emailMultiple }">
            <h6 v-if="emailMultiple">Email code to:</h6>
            <div class="multiple-grp-wrap">
              <v-radio-group
                v-model="protect_acc_form.authStatus"
                :mandatory="true"
              >
                <v-radio
                  @change="getAuthValue('emails', $event)"
                  :value="emails"
                  v-for="(emails, index) in authEmails"
                  :key="index"
                >
                  <div slot="label">
                    <div>
                      <strong v-if="!emailMultiple">Email code to</strong>
                      {{ emails }}
                    </div>
                  </div>
                </v-radio>
              </v-radio-group>
            </div>
          </div>
          <div class="radio-group" :class="{ 'multiple-grp': phoneMultiple }">
            <h6 v-if="phoneMultiple">Text code to:</h6>
            <div class="multiple-grp-wrap">
              <v-radio-group
                v-model="protect_acc_form.authStatus"
                :mandatory="true"
              >
                <v-radio
                  @change="getAuthValue('mobNumber', $event)"
                  :value="mobNumber"
                  v-if="mobNumberOptional"
                >
                  <span slot="label">
                    <span v-if="!phoneMultiple">
                      <strong>Text code to</strong>
                    </span>
                    {{ maskNumber(maskMobNumber) }}
                  </span>
                </v-radio>
              </v-radio-group>
              <p v-if="mobNumberOptional" class="m-l-35">
                Standard data or messaging rates may apply.
              </p>
            </div>
          </div>
        </div>
        <div class="sub-title">
          <p>
            We'll save this for next time. You can change it in your preferences
            on POL My Account.
          </p>
          <!-- &lt;My Account&gt; -->
        </div>
        <div class="form-row">
          <div class="btn-wrap">
            <v-btn
              class="btn btn-primary primary-color"
              @click.prevent="authOtp"
              :disabled="$v.protect_acc_form.$invalid"
              >Next</v-btn
            >
            <CancelButtonComponent
              :btnName="`Cancel`"
              :cancelCategory="`2FAreg.pro`"
            />
          </div>
        </div>
      </section>
    </v-form>
    <FooterComponent />
    <ErrorComponent
      :modelError.sync="accountLocked"
      header-info="Verification Failed"
      body-info="After multiple failed attempts, you are locked out."
      body-description="For additional support, check your email on file or call Tech Support for assistance at <a href='tel:8887372255'>(888) 737-2255</a> for US."
      :onCloseDialog="redirectToLogin"
    />
    <ErrorComponent
      :modelError.sync="noEmailandPhone"
      header-info="We're sorry."
      body-description="Unable to register you online. Please call (888) 737-2255 US for assistance with your account."
      :onCloseDialog="redirectToLogin"
    />
    <LoaderComponent v-if="dataload" />
  </section>
</template>

<script>
import FooterComponent from "@/components/footer-component";
import LoaderComponent from "@/components/loader-component";
import CancelButtonComponent from "@/components/cancel-component";
import { required } from "vuelidate/lib/validators";
import { mapState, mapGetters } from "vuex";
import Api from "../../shared/api";
import Dna from "../../shared/deviceDna.js";
import Gtm from "../../shared/gtm.js";
import ErrorComponent from "@/components/error-component";

export default {
  components: {
    FooterComponent,
    LoaderComponent,
    CancelButtonComponent,
    ErrorComponent,
  },
  data: () => ({
    authEmails: [],
    mobNumber: "",
    maskMobNumber: "",
    mobNumberOptional: false,
    accountLocked: false,
    noEmailandPhone: false,
    genericError: {
      type: "warning",
      message:
        "Unable to register you online. Please call (888) 737-2255 US for assistance with your account.",
    },
    otpSuccessBox: false,
    dataload: true,
    emailMultiple: false,
    phoneMultiple: false,
  }),
  validations: {
    protect_acc_form: {
      authStatus: {
        required,
      },
    },
  },
  computed: {
    ...mapState([
      "protect_acc_form",
      "communication_form",
      "info_form",
      "auth_params",
      "reg_form",
    ]),
    ...mapGetters(["getApplicationSource"]),
  },
  async created() {
    Gtm.gtmPageView("2FAreg.pro");
    if (this.communication_form.mobNumber.length === 10) {
      this.mobNumber = this.communication_form.mobNumber;
      this.maskMobNumber = this.communication_form.mobNumber; // masked mobile number
      this.mobNumberOptional = true;
    }
    // nonprimericaemailid api start
    var nonprimericaemailidHead = {
      agentId: this.reg_form.userId,
      session: this.auth_params.session,
      deviceid: localStorage.getItem("deviceid"),
      deviceDna: await Dna.getDevice(),
      sourceKey: this.reg_form.userId,
      applicationSource: this.getApplicationSource,
      userId: this.reg_form.userId,
      "Content-Type": "application/json",
    };
    Api.getRequest(
      "pol/registration/api/nonprimericaemailid",
      nonprimericaemailidHead
    )
      .then((response) => {
        this.communication_form.nonPrimericaEmail =
          response.data.nonPriEmailAddress;
        this.protect_acc_form.authStatus = "";
        if (
          this.communication_form.nonPrimericaEmail &&
          this.communication_form.nonPrimericaEmail != ""
        ) {
          this.authEmails.push(this.communication_form.nonPrimericaEmail);
        }
         if (
          this.info_form.personalEmailAddress &&
          this.info_form.personalEmailAddress != ""
        ) {
          this.authEmails.push(this.info_form.personalEmailAddress);
        }
        // if (
        //   this.reg_form.emailId &&
        //   this.reg_form.emailId != "" &&
        //   this.communication_form.nonPrimericaEmail.toLowerCase() !=
        //     this.reg_form.emailId.toLowerCase()
        // ) {
        //   this.authEmails.push(this.reg_form.emailId);
        // }
        if (this.authEmails.length == 1) {
          this.phoneMultiple = false;
        }
        if (this.authEmails.length > 1) {
          this.emailMultiple = true;
          this.phoneMultiple = true;
        }
        if (this.communication_form.mobNumber === "") {
          this.phoneMultiple = false;
        }
        this.dataload = false;
      if(this.authEmails.length == 0 && this.communication_form.mobNumber == '') {
        this.noEmailandPhone = true;
      }
      })
      .catch((error) => {
        this.dataload = false;
        this.showBanner(this.genericError);
      });
    // nonprimericaemailid api end
  },
  methods: {
    getAuthValue(val, event) {
      this.protect_acc_form.authType = val == "emails" ? "email" : "text";
      if (val == "emails") {
        this.protect_acc_form.authStatusMask = event;
      } else {
        this.protect_acc_form.authStatusMask = this.maskNumber(event);
      }
    },
    async authOtp() {
      Gtm.gtmClickEvent("event", "2FAreg.pro", "click", "next");
      // authOtp api start
      this.dataload = true;
      var authHead = {
        deviceDna: await Dna.getDevice(),
        "Content-Type": "application/json",
        deviceid: localStorage.getItem("deviceid"),
        session: this.auth_params.session,
        userId: this.reg_form.userId,
        applicationSource: this.getApplicationSource,
      };
      if (this.protect_acc_form.authType == "email") {
        Gtm.gtmChannel("emailCode");
        var authBody = {
          firstName: this.info_form.firstName,
          email: this.protect_acc_form.authStatus,
          // userEmail: this.reg_form.emailId,
        };
      } else {
        Gtm.gtmChannel("textCode");
        var authBody = {
          phone: this.protect_acc_form.authStatus,
          // userEmail: this.reg_form.emailId,
          firstName: this.info_form.firstName,
        };
      }

      Api.postRequest("polregistration/users/mfa/otp", authHead, authBody)
        .then((response) => {
          let data = response.data;
          this.otpSuccessBox = true;
          if (response.status == "201") {
            this.dataload = false;
            this.setPageDestination('auth-otp');
            this.$router.push({
              name: "auth-otp",
              params: { otpSuccess: this.otpSuccessBox },
            });
          }
        })
        .catch((error) => {
          this.dataload = false;
          if (error.response.data.error.errorCode == 4002) {
            this.accountLocked = true;
          } else {
            this.showBanner(this.genericError);
          }
        });
      // authOtp api end
    },
    redirectToLogin() {
      Api.redirectToLogin(this.getApplicationSource);
    },
    maskNumber(val) {
      var data =
        "(" +
        val.substring(0, 3) +
        ") " +
        val.substring(3, 6) +
        " - " +
        val.substring(6, 10);
      return data;
    },
  },
};
</script>
