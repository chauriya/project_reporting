const auth_params = (state) => state.auth_params;
const viewRegistration = (state) => state.ui.viewRegistration;
const sessionBanner = (state) => state.ui.sessionBanner;
const sessionTimer = (state) => state.ui.sessionTimer;
const sessionDialog = (state) => state.ui.sessionDialog;
const getApplicationSource = (state) => state.ui.applicationSource;
const bannerComponent = (state) => state.ui.bannerComponent;
const bannerShow = (state) => state.ui.bannerComponent.show;
const bannerTimer = (state) => state.ui.bannerTimer;
const getPageDestination = state => state.ui.pageDestination;
const hostName = state => state.hostName;

export {
  auth_params,
  viewRegistration,
  sessionBanner,
  sessionTimer,
  sessionDialog,
  getApplicationSource,
  bannerComponent,
  bannerShow,
  bannerTimer,
  getPageDestination,
  hostName
};
