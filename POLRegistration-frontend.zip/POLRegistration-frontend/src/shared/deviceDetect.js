export function getPlatform() {
  var getDeviceVal;
  var isMobile = /iPhone|iPod|Android/i.test(navigator.userAgent);
  var is_iPad = navigator.userAgent.match(/iPad/i) != null;

  var userAgent = navigator.userAgent || navigator.vendor || window.opera;

  if (isMobile) {
    if (/windows phone/i.test(userAgent)) {
      getDeviceVal = "WindowsMobile";
      return getDeviceVal;
    }
    if (/android/i.test(userAgent)) {
      getDeviceVal = "BAPOL";
      return getDeviceVal;
    }

    if (/|iPhone|iPod/.test(userAgent) && !window.MSStream) {
      getDeviceVal = "BIPOL";
      return getDeviceVal;
    }
  } else if (is_iPad) {
    getDeviceVal = "BIPOL";
    return getDeviceVal;
  } else {
    getDeviceVal = "BDPOL";
    return getDeviceVal;
  }
}

export function getDevicePlatform(applicationSource = undefined) {
  if (getPlatform() === "BIPOL" && applicationSource !== undefined) {
    return "DIPRI";
  } else if (getPlatform() === "BAPOL" && applicationSource !== undefined) {
    return "DAPRI";
  } else {
    return getPlatform();
  }
}

//
export function getDeviceName() {
  const { userAgent } = window.navigator;
  if (userAgent.indexOf("iPhone") !== -1) {
    return "iPhone";
  }
  if (userAgent.indexOf("iPad") !== -1) {
    return "iPad";
  }
  if (userAgent.indexOf("LG") !== -1) {
    return "LG";
  }
  if (userAgent.indexOf("KFA") !== -1) {
    return "Kindle Fire";
  }
  if (userAgent.indexOf("Nexus") !== -1) {
    return "Nexus";
  }
  if (userAgent.indexOf("Nokia") !== -1) {
    return "Nokia";
  }
  if (userAgent.indexOf("Pixel") !== -1) {
    return "Pixel";
  }
  if (userAgent.indexOf("SM") !== -1 || userAgent.indexOf("GT") !== -1) {
    return "Samsung";
  }
  if (userAgent.indexOf("Android") !== -1) {
    return "Android";
  }
  if (userAgent.indexOf("Edge") !== -1) {
    return "Microsoft Edge";
  }
  if (userAgent.indexOf("Chrome") !== -1) {
    return "Chrome";
  }
  if (userAgent.indexOf("Firefox") !== -1) {
    return "Firefox";
  }
  if (userAgent.indexOf("Safari") !== -1) {
    return "Safari";
  }
  if (userAgent.indexOf("MSIE") !== -1) {
    return "Microsoft Internet Explorer";
  }
  return "Unknown Device";
}
